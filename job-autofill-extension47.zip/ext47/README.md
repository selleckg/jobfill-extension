# ⚡ JobFill — Auto Apply Assistant

A Chrome Extension that auto-fills job applications across all major platforms.

## Supported Platforms
- LinkedIn Easy Apply
- Workday
- Greenhouse
- Lever
- Indeed
- Taleo
- SmartRecruiters
- iCIMS
- Any ATS with standard HTML forms

## Installation (takes ~60 seconds)

1. **Unzip** this folder somewhere permanent on your Mac  
   (e.g. `~/Documents/JobFill`)

2. **Open Chrome** and go to:  
   `chrome://extensions`

3. **Enable Developer Mode**  
   Toggle the switch in the top-right corner

4. **Click "Load unpacked"**  
   Select the `job-autofill-extension` folder

5. **Pin the extension**  
   Click the puzzle piece 🧩 in Chrome's toolbar → pin JobFill

## How to Use

1. Click the ⚡ JobFill icon in your toolbar
2. Fill in your info across all 4 tabs (Personal, Experience, Education, Cover Letter)
3. Click **Save All Info** — your data is stored locally, never sent anywhere
4. Navigate to any job application page
5. Click **▶ Fill Page** — watch it fill!

## Tips
- Use `{company}` and `{role}` in your cover letter template — they'll be replaced where possible
- Add multiple jobs under Experience; the most recent one is used for single-entry fields
- Your data stays 100% local (Chrome's localStorage) — never uploaded anywhere
- Re-click Fill Page if you navigate to a new step in a multi-page application

## Privacy
All your information is stored locally in your browser using Chrome's `storage.local` API.
Nothing is ever sent to any server. The extension only activates when you click "Fill Page."
