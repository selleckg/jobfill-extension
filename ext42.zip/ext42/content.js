// ── JobFill Content Script v5 ─────────────────────────────────────────────────
(function () {
  'use strict';

  const FIELD_MAP = {
    // ── Compound/specific keys FIRST — must win over generic single-word keys ──
    // Experience company fields (before generic phone/city/state/zip/country)
    exp_compPhone:  [/company\s*phone/i, /employer\s*phone/i, /business\s*phone/i],
    exp_compStreet1:[/company\s*address\s*(line\s*1)?/i, /employer\s*address\s*(line\s*1)?/i, /business\s*address\s*(line\s*1)?/i],
    exp_compStreet2:[/company\s*address\s*line\s*2/i, /employer\s*address\s*line\s*2/i, /business\s*address\s*line\s*2/i],
    exp_compCity:   [/company\s*city/i, /employer\s*city/i, /business\s*city/i],
    exp_compState:  [/company\s*state/i, /employer\s*state/i],
    exp_compZip:    [/company\s*zip/i, /employer\s*zip/i, /business\s*zip/i],
    exp_compCountry:[/company\s*country/i, /employer\s*country/i],
    exp_company:    [/company\s*name/i, /employer\s*name/i, /organization\s*name/i,
                     /(current|previous|last|recent|prior)\s*(employer|company|organization)/i,
                     /\bcompany\b/i, /\bemployer\b/i],
    exp_startDate:  [/start\s*date/i, /from\s*date/i, /date\s*started/i, /hire\s*date/i],
    exp_endDate:    [/end\s*date/i, /to\s*date/i, /through\b/i, /date\s*(ended|left|terminated)/i],
    exp_description:[/description\b/i, /responsibilities/i, /duties/i, /achievements/i,
                     /job\s*(responsibilities|duties)/i, /work\s*experience\s*description/i],
    exp_empType:    [/employment\s*type/i, /job\s*type/i, /work\s*type/i, /position\s*type/i,
                     /type\s*of\s*(employment|position|work)/i, /employment\s*status/i],
    // References BEFORE exp_title so "Reference Title" matches ref_title not exp_title
    ref_name:       [/reference.*name/i, /referee.*name/i],
    ref_title:      [/reference.*title/i, /referee.*title/i],
    ref_company:    [/reference.*company/i, /reference.*organization/i, /referee.*company/i,
                     /referee.*employer/i],
    ref_phone:      [/reference.*phone/i, /referee.*phone/i],
    ref_email:      [/reference.*e[\-\s]?mail/i, /referee.*e[\-\s]?mail/i],
    exp_title:      [/job\s*title/i, /position\s*title/i, /current\s*(position|role|title)/i,
                     /\bposition\b/i, /\brole\b/i, /\btitle\b/i],
    // Education
    edu_school:     [/school\b/i, /university\b/i, /college\b/i, /institution\b/i],
    edu_degree:     [/degree\b/i, /qualification\b/i, /diploma\b/i],
    edu_field:      [/major\b/i, /field\s*of\s*study/i, /concentration\b/i],
    edu_gradYear:   [/graduation\s*year/i, /grad\s*year/i, /year\s*of\s*graduation/i],
    edu_startYear:  [/start\s*year/i, /enrollment\s*year/i, /year\s*(started|enrolled|began)/i, /from\s*year/i],
    edu_gpa:        [/\bgpa\b/i, /grade\s*point/i],
    // ── Generic personal keys AFTER compound keys ─────────────────────────────
    fullName:       [/full\s*name/i, /legal\s*name/i, /complete\s*name/i, /candidate\s*name/i,
                     /applicant\s*name/i, /your\s*name/i],
    firstName:      [/first\s*name/i, /given\s*name/i, /fname/i],
    middleName:     [/middle\s*name/i, /middle\s*initial/i, /\bmname\b/i],
    lastName:       [/last\s*name/i, /surname/i, /family\s*name/i, /lname/i],
    email:          [/e[\-\s]?mail/i, /email\s*address/i],
    phone:          [/\bphone\b/i, /mobile\b/i, /cell\b/i, /telephone\b/i, /contact\s*number/i,
                     /mobile\s*number/i, /phone\s*number/i],
    linkedin:       [/linkedin/i],
    street1:        [/street\s*address\s*(line\s*1)?/i, /address\s*line\s*1/i, /^address$/i, /addr1/i, /mailing\s*address/i],
    street2:        [/street\s*address\s*line\s*2/i, /address\s*line\s*2/i, /apt\b/i, /suite\b/i, /addr2/i, /unit\b/i],
    city:           [/\bcity\b/i, /\btown\b/i],
    state:          [/\bstate\b/i, /province\b/i, /region\b/i],
    zip:            [/zip\b/i, /postal\s*code/i, /post\s*code/i],
    country:        [/\bcountry\b/i],
    website:        [/website/i, /portfolio/i, /personal\s*(url|site)/i],
    github:         [/github/i],
    salary:         [/salary/i, /compensation/i, /desired\s*pay/i, /expected\s*pay/i,
                     /pay\s*expectation/i, /desired\s*compensation/i],
    yearsExp:       [/years?\s*(of\s*)?experience/i, /how\s*many\s*years/i],
    gender:         [/\bgender\b/i, /\bsex\b(?!\s*ual)/i],
    raceEthnicity:  [/race\s*[\/&]\s*ethnicity/i, /race\s*and\s*ethnicity/i, /\bethnicity\b/i,
                     /race\s*origin/i, /racial\s*background/i, /\brace\b(?!\s*car)/i],
    workAuth:       [/work\s*auth/i, /authorized\s*to\s*work/i, /legally\s*authorized/i,
                     /eligible\s*to\s*work/i, /permission\s*to\s*work/i, /visa\s*status/i,
                     /immigration\s*status/i, /right\s*to\s*work/i],
    sponsorship:    [/sponsor/i, /visa\s*sponsor/i, /require\s*sponsor/i, /need\s*sponsor/i],
    coverLetter:    [/cover\s*letter/i, /covering\s*letter/i, /motivation\s*letter/i],
    whyRole:        [/why\s*(do\s*you\s*want|are\s*you\s*interest)/i, /why\s*this\s*(role|position|job)/i,
                     /why\s*(apply|applying)/i, /interest\s*in\s*(this|the)\s*(role|position|job)/i],
    skills:         [/\bskills?\s*summary/i, /key\s*skills?/i, /core\s*competenc/i,
                     /technical\s*skills?\s*(summary)?/i, /qualifications?\s*summary/i,
                     /relevant\s*skills?/i],
    aboutMe:        [/tell\s*(us|me)\s*about\s*yourself/i, /about\s*yourself/i,
                     /introduce\s*yourself/i, /professional\s*summary/i, /\bsummary\b/i,
                     /professional\s*(background|profile|synopsis)/i, /brief\s*(bio|description)/i],
    strength:       [/greatest?\s*strength/i, /key\s*strength/i, /top\s*strength/i],
    weakness:       [/greatest?\s*weakness/i, /area\s*for\s*improvement/i, /development\s*area/i],
    hearAbout:      [/how\s*did\s*you\s*(hear|find|learn)/i, /where\s*did\s*you\s*(hear|find|see)/i,
                     /how\s*did\s*you\s*come\s*across/i, /source\s*of\s*(referral|application)/i],
  };

  // ── Registry for FILL_ONE ──────────────────────────────────────────────────
  let _reg = {};
  let _cnt = 0;
  function regEl(el) {
    const id = '_jf_' + (++_cnt);
    _reg[id] = el;
    return id;
  }

  // ── Label extraction ───────────────────────────────────────────────────────
  function getLabel(el) {
    if (el.getAttribute('aria-label')) return el.getAttribute('aria-label');
    if (el.id) {
      try {
        const lbl = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (lbl) return lbl.innerText || lbl.textContent;
      } catch(e) {}
    }
    const pLabel = el.closest('label');
    if (pLabel) return pLabel.innerText || pLabel.textContent;
    const parent = el.parentElement;
    if (parent) {
      const lbl = parent.querySelector('label');
      if (lbl) return lbl.innerText || lbl.textContent;
      const prev = parent.previousElementSibling;
      if (prev && /^(label|span|div|p|legend)$/i.test(prev.tagName))
        return prev.innerText || prev.textContent;
    }
    return el.placeholder || el.name || el.id || '';
  }

  function matchKey(el) {
    const label    = getLabel(el) || '';
    const combined = [label, el.name||'', el.id||'', el.placeholder||''].join(' ');
    for (const [key, pats] of Object.entries(FIELD_MAP)) {
      if (pats.some(p => p.test(combined))) return key;
    }
    return null;
  }

  // ── Value setter (works with React/Vue synthetic events) ──────────────────
  function setVal(el, value) {
    const proto  = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(el, value); else el.value = value;
    ['input','change','blur'].forEach(ev => el.dispatchEvent(new Event(ev, {bubbles:true})));
  }

  function fillSelect(el, value) {
    const opts  = Array.from(el.options);
    const lower = value.toLowerCase();
    const exact = opts.find(o => o.text.toLowerCase() === lower || o.value.toLowerCase() === lower);
    if (exact) { el.value = exact.value; }
    else {
      const partial = opts.find(o => o.text.toLowerCase().includes(lower) || lower.includes(o.text.toLowerCase()));
      if (!partial) return false;
      el.value = partial.value;
    }
    el.dispatchEvent(new Event('change',{bubbles:true}));
    return true;
  }

  // ── Main fill ─────────────────────────────────────────────────────────────
  function fillForm(data) {
    const { personal={}, location={}, experiences=[], educations=[], cover={},
            refs=[], overviews=[], skillSets=[] } = data;
    _reg = {}; _cnt = 0;

    // Build flat value map — personal + location + cover text fields
    const flat = { ...personal, ...location, ...cover };

    // Suppress online presence fields if the user unchecked their useInFill boxes
    if (personal.linkedinUse === false) delete flat.linkedin;
    if (personal.websiteUse  === false) delete flat.website;
    if (personal.githubUse   === false) delete flat.github;

    // fullName synthesised from first + middle + last
    if (personal.firstName || personal.lastName) {
      flat.fullName = [personal.firstName, personal.middleName, personal.lastName].filter(Boolean).join(' ');
    }

    // ── Active overview → aboutMe / summary fields ────────────────────────
    const activeOverview = overviews.find(o => o.useInFill !== false);
    if (activeOverview && activeOverview.text) {
      // Use overview text for aboutMe/summary fields if not already set from cover
      if (!flat.aboutMe) flat.aboutMe = activeOverview.text;
    }

    // ── Active skill set → skills fields ─────────────────────────────────
    const activeSkillSet = skillSets.find(s => s.useInFill !== false);
    if (activeSkillSet && activeSkillSet.text) {
      flat.skills = activeSkillSet.text;
    }

    // ── First active experience ───────────────────────────────────────────
    const activeExp = experiences.find(e => e.useInFill !== false);
    if (activeExp) {
      const exp = activeExp;
      flat.exp_company     = exp.company      || '';
      flat.exp_compPhone   = exp.companyPhone  || '';
      flat.exp_compStreet1 = exp.compStreet1   || '';
      flat.exp_compStreet2 = exp.compStreet2   || '';
      flat.exp_compCity    = exp.compCity      || '';
      flat.exp_compState   = exp.compState     || '';
      flat.exp_compZip     = exp.compZip       || '';
      flat.exp_compCountry = exp.compCountry   || '';
      // Use active title based on radio selection (0=primary,1=alt1,2=alt2)
      // Coerce to number — activeTitleIdx may be stored as a string after CSV import
      const ati = +(exp.activeTitleIdx ?? 0);
      flat.exp_title = ati === 1 ? (exp.altTitle1 || exp.title || '')
                     : ati === 2 ? (exp.altTitle2 || exp.title || '')
                     : (exp.title || '');
      flat.exp_empType    = exp.empType || '';
      const sm = exp.startMonth, sd = exp.startDay, sy = exp.startYear;
      flat.exp_startDate  = [sm,sd,sy].filter(Boolean).join('/') || '';
      flat.exp_endDate    = exp.present ? 'Present' : [exp.endMonth,exp.endDay,exp.endYear].filter(Boolean).join('/') || '';
      // Build description from checked sentences only
      let expDesc = exp.description || '';
      if (exp.sentences && exp.sentences.length) {
        const active = exp.sentences
          .filter((s, idx) => !exp.sentenceChecked || exp.sentenceChecked[idx] !== false)
          .join(' ').trim();
        if (active) expDesc = active;
      }
      flat.exp_description = expDesc;
    }

    // ── Education ────────────────────────────────────────────────────────
    if (educations.length) {
      const edu = educations[0];
      flat.edu_school    = edu.school    || '';
      flat.edu_degree    = edu.degree    || '';
      flat.edu_field     = edu.field     || '';
      flat.edu_gradYear  = edu.gradYear  || '';
      flat.edu_startYear = edu.startYear || '';
      flat.edu_gpa       = edu.gpa       || '';
    }

    // ── First active reference ────────────────────────────────────────────
    const activeRef = (refs || []).find(r => r.useInFill !== false);
    if (activeRef) {
      flat.ref_name    = activeRef.name    || '';
      flat.ref_title   = activeRef.title   || '';
      flat.ref_company = activeRef.company || '';
      flat.ref_phone   = activeRef.phone   || '';
      flat.ref_email   = activeRef.email   || '';
    }

    let filled = 0;
    const unfilled = [];

    const inputs = document.querySelectorAll(
      'input:not([type=hidden]):not([type=submit]):not([type=button])' +
      ':not([type=checkbox]):not([type=radio]):not([type=file]),textarea,select'
    );

    inputs.forEach(el => {
      if (el.disabled || el.readOnly) return;
      const key = matchKey(el);
      if (!key) return;
      let value = flat[key] || '';

      if (!value) {
        const label = (getLabel(el)||key).trim();
        if (label.length > 1) {
          const guess = buildGuess(key, flat);
          unfilled.push({ label, elementId: regEl(el), guess: guess || '' });
        }
        return;
      }

      if (key === 'coverLetter') {
        value = value.replace(/\{company\}/gi,'your company').replace(/\{role\}/gi,'this position');
      }

      if (el.tagName === 'SELECT') {
        if (fillSelect(el, value)) filled++;
        else unfilled.push({ label: getLabel(el)||key, elementId: regEl(el), guess: value });
      } else {
        if (el.value !== value) { setVal(el, value); filled++; }
      }
    });

    handleRadios(personal.sponsorship, ['sponsor','sponsorship']);
    handleRadios('No', ['legally authorized','authorized to work','eligible to work','us citizen']);

    return { filled, unfilled };
  }

  function buildGuess(key, flat) {
    if (key.includes('name'))    return flat.firstName ? `${flat.firstName} ${flat.lastName}`.trim() : '';
    if (key.includes('city'))    return flat.city    || '';
    if (key.includes('state'))   return flat.state   || '';
    if (key.includes('country')) return flat.country || '';
    return '';
  }

  function handleRadios(value, keywords) {
    if (!value) return;
    const isYes = value.toLowerCase().startsWith('y');
    document.querySelectorAll('input[type=radio]').forEach(r => {
      const lbl = getLabel(r).toLowerCase();
      if (!keywords.some(kw => lbl.includes(kw))) return;
      const v = (r.value||'').toLowerCase();
      if ((isYes  && (v==='yes'||v==='true'||v==='1')) ||
          (!isYes && (v==='no'||v==='false'||v==='0'))) {
        r.checked = true;
        r.dispatchEvent(new Event('change',{bubbles:true}));
      }
    });
  }

  // ── Message listener ──────────────────────────────────────────────────────
  // ── SECURITY: only accept messages from our own extension ────────────────────
  const OWN_ID = chrome.runtime.id;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Reject any message not originating from this extension's own pages/background
    if (!sender || sender.id !== OWN_ID) return;

    if (msg.action === 'FILL_FORM') {
      try {
        const result = fillForm(msg.data);
        sendResponse({ filled: result.filled, unfilled: result.unfilled, success: true });
      } catch (e) {
        sendResponse({ filled: 0, unfilled: [], success: false, error: e.message });
      }
      return true;
    }
    if (msg.action === 'FILL_ONE') {
      try {
        const el = _reg[msg.elementId];
        if (el) {
          if (el.tagName === 'SELECT') fillSelect(el, msg.value);
          else setVal(el, msg.value);
        }
        sendResponse({ success: true });
      } catch(e) { sendResponse({ success: false }); }
      return true;
    }
  });

})();
