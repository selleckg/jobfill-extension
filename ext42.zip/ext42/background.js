// ── JobFill Background Service Worker ────────────────────────────────────────
// Handles CRAFT_RESUME messages from the popup.
// Generates a .docx resume using the docx library via offscreen document.

// Color theme definitions — header images + color values
const THEMES = {
  gunsmoke1: {
    headerB64:     "iVBORw0KGgoAAAANSUhEUgAABVkAAACsCAIAAADuYTsQAAAC/0lEQVR4nO3asQ2AMAADwYCYiP1rREXFPrBFUvzdBK5fHgMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKjYvvtcvQEAAACYZ189AAAAAJhKCwAAAICW43qf1RsAAACAefwCAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaPkBHC4Eg16wYbIAAAAASUVORK5CYII=",
    goldRuleColor: "C59C00",   // gold rule under name
    sectionBorder: "BFBFBF",   // silver section heading borders
    hasHeader:     true,
  },
  aquaman: {
    headerB64:     "iVBORw0KGgoAAAANSUhEUgAABVkAAACsCAIAAADuYTsQAAAEY0lEQVR4nO3aMRWEMABEweQU4gMNuLyCggIpuEiKP6Ng6/92jvMaAAAAQMZv9wAAAABgKS0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABomcfz7t4AAAAArOMXAAAAAC1aAAAAALTM8b93bwAAAADW8QsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKBFCwAAAIAWLQAAAABatAAAAABo0QIAAACg5QMlpwX28UYo1AAAAABJRU5ErkJggg==",
    goldRuleColor: "00D4D8",   // aqua rule under name
    sectionBorder: "80D4D8",   // light aqua section borders
    hasHeader:     true,
  },
  cleanslate: {
    headerB64:     "",
    goldRuleColor: "",         // no rule — just a blank line
    sectionBorder: "CCCCCC",   // light grey section borders
    hasHeader:     false,
  },
  blues: {
    headerB64:     "iVBORw0KGgoAAAANSUhEUgAABVkAAACsCAIAAADuYTsQAAAEaElEQVR4nO3aMRGEQAAEQaBQ8VKwhAE84eYFfPYqSHBxF0y3go2ndv0c5wIAAABkbLMHAAAAAENpAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQIsWAAAAAC1aAAAAALRoAQAAANCiBQAAAECLFgAAAAAtWgAAAAC0aAEAAADQogUAAABAixYAAAAALVoAAAAAtGgBAAAA0KIFAAAAQMt63b/ZGwAAAIBx/AIAAACgRQsAAACAlv37f2ZvAAAAAMbxCwAAAIAWLQAAAABatAAAAABo0QIAAACgRQsAAACAFi0AAAAAWrQAAAAAaNECAAAAoEULAAAAgBYtAAAAAFq0AAAAAGjRAgAAAKDlBfXCBstbxjMJAAAAAElFTkSuQmCC",
    goldRuleColor: "4A90D9",   // blue rule under name
    sectionBorder: "7AABDE",   // light blue section borders
    hasHeader:     true,
  },
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'CRAFT_RESUME') {
    handleCraftResume(msg).then(sendResponse).catch(err => sendResponse({ success: false, error: err.message }));
    return true; // keep channel open for async response
  }
});

async function handleCraftResume({ payload, fileB64, fileName, isTemplate, theme }) {
  try {
    // Build the resume docx content as a data URL via offscreen
    // Since we can't use Node.js npm packages directly in the extension,
    // we generate the docx using pure XML construction (OOXML) which we
    // assemble directly — no external library needed in the extension itself.
    const docxB64 = buildResumeDocx(payload, theme || 'gunsmoke1');

    // Trigger download
    const dataUrl = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + docxB64;
    const firstName = payload.personal?.firstName || 'Resume';
    const lastName  = payload.personal?.lastName  || '';
    const name = (firstName + '_' + lastName).replace(/\s+/g, '_').replace(/[^a-zA-Z0-9_]/g, '');
    await chrome.downloads.download({
      url:      dataUrl,
      filename: `${name}_Resume.docx`,
      saveAs:   false,
    });

    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ── Pure OOXML resume generator ───────────────────────────────────────────────
// Builds a .docx file as a base64 string using JSZip-style manual construction.
// Matches the styling of the sample resume:
//   Font: Garamond, Page: US Letter, Margins: 1" top/bottom, 0.75" left/right
//   Name: 24pt, Location: 16pt, Section headings: 14pt SMALL CAPS
//   Job title: 13.5pt bold, Bullets: ~12pt, spacing: 14pt before/after job blocks


function buildResumeDocx(data, themeName = 'gunsmoke1') {
  const theme = THEMES[themeName] || THEMES.gunsmoke1;
  const { personal={}, location={}, cover={}, overview, skills,
          experiences=[], educations=[], certs=[], refs=[] } = data;

  const paras = [];

  // ── Helper: make a paragraph XML string ──────────────────────────────────
  function p(text, opts = {}) {
    const {
      size = 24,        // half-points (24 = 12pt)
      bold = false,
      smallCaps = false,
      spBefore = 0,     // pt * 20 = twips
      spAfter = 0,
      font = 'Garamond',
      bullet = false,
      numId = 1,
      indent = 0,
    } = opts;

    const rpr = [
      `<w:rFonts w:ascii="${font}" w:hAnsi="${font}" w:cs="${font}"/>`,
      `<w:sz w:val="${size}"/>`,
      `<w:szCs w:val="${size}"/>`,
      bold      ? '<w:b/><w:bCs/>' : '',
      smallCaps ? '<w:smallCaps/>' : '',
    ].filter(Boolean).join('');

    // Always emit explicit spacing so Word cannot inherit Normal-style defaults (e.g. 8pt after).
    // When spBefore/spAfter are both 0 this produces w:before="0" w:after="0" — forcing "No Spacing".
    const ppr_spacing = `<w:spacing w:before="${spBefore * 20}" w:after="${spAfter * 20}"/>`;

    const ppr_num = bullet
      ? `<w:numPr><w:ilvl w:val="0"/><w:numId w:val="${numId}"/></w:numPr>`
      : '';

    const ppr_ind = indent
      ? `<w:ind w:left="${indent}"/>`
      : '';

    const ppr = (ppr_spacing || ppr_num || ppr_ind)
      ? `<w:pPr>${ppr_spacing}${ppr_num}${ppr_ind}</w:pPr>`
      : '';

    // Escape XML
    const escaped = String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

    const space = (escaped.startsWith(' ') || escaped.endsWith(' '))
      ? ' xml:space="preserve"' : '';

    return `<w:p>${ppr}<w:r><w:rPr>${rpr}</w:rPr><w:t${space}>${escaped}</w:t></w:r></w:p>`;
  }

  // ── Helper: section heading ───────────────────────────────────────────────
  function sectionHeading(text, bold = false) {
    // Matches original: 14pt small caps, silver bottom border (BFBFBF), letter spacing 24
    const boldEl = bold ? '<w:b/>' : '';
    const rpr = `<w:rFonts w:ascii="Garamond" w:hAnsi="Garamond" w:cs="Garamond"/>
      ${boldEl}
      <w:smallCaps/>
      <w:color w:val="000000"/>
      <w:spacing w:val="24"/>
      <w:sz w:val="28"/>
      <w:szCs w:val="28"/>`;
    const escaped = String(text).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<w:p>
      <w:pPr>
        <w:pBdr><w:bottom w:val="single" w:sz="8" w:space="1" w:color="${theme.sectionBorder}"/></w:pBdr>
        <w:spacing w:before="0" w:after="240"/>
        <w:rPr>${rpr}</w:rPr>
      </w:pPr>
      <w:r><w:rPr>${rpr}</w:rPr><w:t>${escaped}</w:t></w:r>
    </w:p>`;
  }

  // ── Helper: empty paragraph ───────────────────────────────────────────────
  function emptyP(spBefore = 0, spAfter = 0) {
    const sp = (spBefore || spAfter)
      ? `<w:pPr><w:spacing w:before="${spBefore*20}" w:after="${spAfter*20}"/></w:pPr>`
      : '<w:pPr/>';
    return `<w:p>${sp}</w:p>`;
  }

  // ── Helper: horizontal rule (silver — matches original resume) ──────────────
  function hrLine() {
    return `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="${theme.sectionBorder}"/></w:pBdr><w:spacing w:before="0" w:after="120"/></w:pPr></w:p>`;
  }

  // ── Helper: accent rule under name block (theme color) ───────────────────────
  function goldRule() {
    if (!theme.goldRuleColor) return `<w:p><w:pPr><w:spacing w:before="0" w:after="160"/></w:pPr></w:p>`;
    return `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="18" w:space="1" w:color="${theme.goldRuleColor}"/></w:pBdr><w:spacing w:before="0" w:after="160"/></w:pPr></w:p>`;
  }

  // ── 1. NAME & CONTACT HEADER ──────────────────────────────────────────────
  // Always compute these — used in both body (cleanslate) and header (themed)
  const fullName = [personal.firstName, personal.middleName, personal.lastName].filter(Boolean).join(' ');
  const cityState = [location.city, location.state].filter(Boolean).join(', ');
  // Respect per-field useInFill flags (default true if not set)
  const contactParts = [
    personal.email,
    personal.phone,
    personal.linkedinUse !== false ? personal.linkedin : null,
    personal.websiteUse !== false  ? personal.website  : null,
    personal.githubUse  !== false  ? personal.github   : null,
  ].filter(Boolean);

  // For non-header themes (e.g. cleanslate): put name/contact in the document body
  if (!theme.hasHeader) {
    if (fullName) paras.push(p(fullName, { size: 48, bold: true }));
    if (cityState) paras.push(p(cityState, { size: 24 }));
    if (contactParts.length) paras.push(p(contactParts.join('  |  '), { size: 22 }));
  }
  // For header themes: name/contact are embedded in headerXml (below) as bold white text

  // Gold accent rule — matches the theme color bar
  paras.push(goldRule());

  // ── 2. SUMMARY / OVERVIEW ─────────────────────────────────────────────────
  if (overview?.text || cover?.aboutMe) {
    paras.push(sectionHeading('Experience Depth'));
    const summaryText = overview?.text || cover?.aboutMe;
    paras.push(p(summaryText, { size: 24, spAfter: 12 }));
  }

  // ── 3. SKILLS / EXPERTISE ─────────────────────────────────────────────────
  if (skills?.text) {
    paras.push(sectionHeading('Expertise'));
    // Split comma-separated skills into bullet groups of ~4
    const skillList = skills.text.split(',').map(s => s.trim()).filter(Boolean);
    // Group into a few bullet categories or just list them
    if (skillList.length > 0) {
      // Output as a single paragraph with the skills text
      paras.push(p(skills.text, { size: 24, spAfter: 12 }));
    }
  }

  // ── 4. EXPERIENCE ─────────────────────────────────────────────────────────
  if (experiences.length) {
    paras.push(sectionHeading('Professional History'));

    for (const exp of experiences) {
      // Job title — 14pt space before each block to separate jobs, 0 after (tight layout)
      paras.push(p(exp.activeTitle || exp.title || '', { size: 27, bold: true, spBefore: 14, spAfter: 0 }));

      // Company | Location | Dates — no extra spacing; items flow tightly
      const startStr = [exp.startMonth, exp.startYear].filter(Boolean).join('/');
      const endStr   = exp.present ? 'Present' : [exp.endMonth, exp.endYear].filter(Boolean).join('/');
      const dateRange = [startStr, endStr].filter(Boolean).join(' – ');
      const compLine = [
        exp.company,
        exp.compCity && exp.compState ? `${exp.compCity}, ${exp.compState}` : (exp.compCity || exp.compState || ''),
        dateRange,
      ].filter(Boolean).join('  |  ');
      if (compLine) paras.push(p(compLine, { size: 24, spBefore: 0, spAfter: 0 }));

      // Description as bullets — no extra spacing between bullets
      if (exp.description) {
        const sentences = exp.description.split(/(?<=[.!?])\s+/).filter(s => s.trim());
        for (const sent of sentences) {
          paras.push(p(sent.trim(), { size: 24, bullet: true, numId: 1 }));
        }
        // No spAfter override — the next job title's spBefore provides separation
      }
    }
  }

  // ── 5. EDUCATION ──────────────────────────────────────────────────────────
  if (educations.length) {
    paras.push(emptyP(6, 0));
    paras.push(sectionHeading('Certifications and Education', true));
    paras.push(p('EDUCATION', { size: 24, bold: true, spBefore: 14, spAfter: 14 }));
    for (const edu of educations) {
      const degreeStr = [edu.degree, edu.field ? `in ${edu.field}` : '', edu.miscData || ''].filter(Boolean).join(' ');
      const schoolStr = [edu.school, edu.gradYear ? `Graduated ${edu.gradYear}` : ''].filter(Boolean).join('  |  ');
      if (degreeStr) paras.push(p(degreeStr, { size: 24 }));
      if (schoolStr) paras.push(p(schoolStr, { size: 24, spAfter: 14 }));
    }
  }

  // ── 6. CERTIFICATIONS ────────────────────────────────────────────────────
  if (certs.length) {
    if (!educations.length) { paras.push(emptyP(6, 0)); paras.push(sectionHeading('Certifications and Education', true)); }
    paras.push(p('CERTIFICATIONS', { size: 24, bold: true, spBefore: 14, spAfter: 14 }));
    for (const cert of certs) {
      const parts = [cert.name];
      if (cert.authority) parts.push(cert.authority);
      if (cert.certNum)   parts.push(`Certificate #${cert.certNum}`);
      const dateStr = cert.completedMonth && cert.completedYear
        ? `Issued ${cert.completedMonth}/${cert.completedYear}` : '';
      if (dateStr) parts.push(dateStr);
      parts.push(cert.current === false ? 'Expired' : 'Current');
      paras.push(p(parts.join('  |  '), { size: 24, bullet: true, numId: 1 }));
    }
  }

  // ── 7. REFERENCES ────────────────────────────────────────────────────────
  if (refs.length) {
    paras.push(emptyP(6, 0));
    paras.push(sectionHeading('References', true));
    for (const ref of refs) {
      const refLine = [ref.name, ref.title, ref.company, ref.phone].filter(Boolean).join('  |  ');
      if (refLine) paras.push(p(refLine, { size: 24, bullet: true, numId: 1 }));
    }
  }

  const bodyXml = paras.join('\n');

  // ── NUMBERING XML (bullet list definition) ────────────────────────────────
  const numberingXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:abstractNum w:abstractNumId="0">
    <w:lvl w:ilvl="0">
      <w:start w:val="1"/>
      <w:numFmt w:val="bullet"/>
      <w:lvlText w:val="&#x2022;"/>
      <w:lvlJc w:val="left"/>
      <w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr>
      <w:rPr><w:rFonts w:ascii="Symbol" w:hAnsi="Symbol" w:cs="Symbol"/></w:rPr>
    </w:lvl>
  </w:abstractNum>
  <w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>
</w:numbering>`;

  // ── DOCUMENT XML ─────────────────────────────────────────────────────────
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
            xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    ${bodyXml}
    <w:sectPr>
      ${theme.hasHeader ? '<w:titlePg/><w:headerReference w:type="first" r:id="rId3"/>' : ''}
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="${theme.hasHeader ? 1800 : 1440}" w:right="1080" w:bottom="1440" w:left="1080"
               w:header="${theme.hasHeader ? 360 : 720}" w:footer="720" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>`;

  // ── STYLES XML ───────────────────────────────────────────────────────────
  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault><w:rPr>
      <w:rFonts w:ascii="Garamond" w:hAnsi="Garamond" w:cs="Garamond"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/>
    </w:rPr></w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Normal" w:default="1">
    <w:name w:val="Normal"/>
    <w:rPr>
      <w:rFonts w:ascii="Garamond" w:hAnsi="Garamond"/>
      <w:sz w:val="24"/><w:szCs w:val="24"/>
    </w:rPr>
  </w:style>
</w:styles>`;

  // ── RELATIONSHIPS ─────────────────────────────────────────────────────────
  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>
  ${theme.hasHeader ? '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target=\"header1.xml\"/>' : ''}
</Relationships>`;

  // Helper: XML-escape a plain string for embedding in OOXML text runs
  const xmlEsc = s => String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  // Contact line for the header (city/state + email + phone + linkedin + website)
  const headerContactLine = [cityState, ...contactParts].filter(Boolean).join('  |  ');

  // Header XML — dark banner image anchored BEHIND the text layer (behindDoc="1"),
  // so white bold name + contact paragraphs appear ON TOP of the image.
  //
  // Positioning (EMU units, 1 inch = 914400 EMU = 1440 twips):
  //   • cy = 1143000 EMU = exactly 1.25" — matches the w:top="1800" twip top margin so
  //     the image fills the entire header zone top-to-bottom with no gap or overflow.
  //   • cx = 9296280 (~10.17") bleeds past both page edges for a full-bleed look.
  //   • w:before="0" on the name paragraph places text at the very top of the header
  //     content zone (which itself starts 0.25" from the physical page top), giving
  //     the maximum dark-space cushion above the text and ensuring long contact lines
  //     that wrap stay comfortably within the dark band.
  const headerNameXml = fullName ? `
  <w:p>
    <w:pPr>
      <w:ind w:start="360"/>
      <w:spacing w:before="0" w:after="0"/>
    </w:pPr>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="Garamond" w:hAnsi="Garamond" w:cs="Garamond"/>
        <w:b/><w:bCs/>
        <w:color w:val="FFFFFF"/>
        <w:sz w:val="44"/><w:szCs w:val="44"/>
      </w:rPr>
      <w:t>${xmlEsc(fullName)}</w:t>
    </w:r>
  </w:p>` : '';

  const headerContactXml = headerContactLine ? `
  <w:p>
    <w:pPr>
      <w:ind w:start="360"/>
      <w:spacing w:before="0" w:after="0"/>
    </w:pPr>
    <w:r>
      <w:rPr>
        <w:rFonts w:ascii="Garamond" w:hAnsi="Garamond" w:cs="Garamond"/>
        <w:color w:val="FFFFFF"/>
        <w:sz w:val="18"/><w:szCs w:val="18"/>
      </w:rPr>
      <w:t>${xmlEsc(headerContactLine)}</w:t>
    </w:r>
  </w:p>` : '';

  const headerXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
       xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
       xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
       xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"
       xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:p>
    <w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>
    <w:r><w:drawing>
      <wp:anchor distT="0" distB="0" distL="0" distR="0"
                 simplePos="0" relativeHeight="2" behindDoc="1"
                 locked="0" layoutInCell="1" allowOverlap="0">
        <wp:simplePos x="0" y="0"/>
        <wp:positionH relativeFrom="page">
          <wp:posOffset>0</wp:posOffset>
        </wp:positionH>
        <wp:positionV relativeFrom="page">
          <wp:posOffset>0</wp:posOffset>
        </wp:positionV>
        <wp:extent cx="9296280" cy="1143000"/>
        <wp:effectExtent l="0" t="0" r="0" b="0"/>
        <wp:wrapNone/>
        <wp:docPr id="1" name="HeaderImg" descr="" title=""/>
        <wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>
        <a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
          <pic:pic>
            <pic:nvPicPr>
              <pic:cNvPr id="1" name="HeaderImg" descr="" title=""/>
              <pic:cNvPicPr><a:picLocks noChangeAspect="1"/></pic:cNvPicPr>
            </pic:nvPicPr>
            <pic:blipFill>
              <a:blip r:embed="rId1"/>
              <a:stretch><a:fillRect/></a:stretch>
            </pic:blipFill>
            <pic:spPr>
              <a:xfrm><a:off x="0" y="0"/><a:ext cx="9296280" cy="1143000"/></a:xfrm>
              <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
            </pic:spPr>
          </pic:pic>
        </a:graphicData></a:graphic>
      </wp:anchor>
    </w:drawing></w:r>
  </w:p>${headerNameXml}${headerContactXml}
</w:hdr>`;

  const headerRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/header.png"/>
</Relationships>`;

  const appRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml"  ContentType="application/xml"/>
  ${theme.hasHeader ? '<Default Extension="png" ContentType="image/png"/>' : ''}
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml"   ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>
  ${theme.hasHeader ? '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' : ''}
</Types>`;

  // ── ASSEMBLE ZIP (using inline base64 zip builder) ────────────────────────
  // Decode header image from base64 to binary string
  const headerImgBytes = theme.hasHeader ? atob(theme.headerB64) : '';

  const files = {
    '[Content_Types].xml':        contentTypesXml,
    '_rels/.rels':                appRelsXml,
    'word/document.xml':          documentXml,
    'word/styles.xml':            stylesXml,
    'word/numbering.xml':         numberingXml,
    'word/_rels/document.xml.rels': relsXml,
    ...(theme.hasHeader ? {
      'word/header1.xml':           headerXml,
      'word/_rels/header1.xml.rels': headerRelsXml,
      'word/media/header.png':      headerImgBytes,
    } : {}),
  };

  return buildZipBase64(files);
}

// ── Minimal ZIP builder (no dependencies) ─────────────────────────────────────
function buildZipBase64(files) {
  // Build a ZIP file from filename→content string pairs
  // Returns base64-encoded ZIP bytes

  function strToBytes(str) {
    const arr = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) arr[i] = str.charCodeAt(i) & 0xff;
    return arr;
  }

  function utf8Encode(str) {
    return new TextEncoder().encode(str);
  }

  function crc32(data) {
    const table = crc32.table || (crc32.table = (() => {
      const t = new Uint32Array(256);
      for (let i = 0; i < 256; i++) {
        let c = i;
        for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        t[i] = c;
      }
      return t;
    })());
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < data.length; i++) crc = table[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function uint16LE(n) { return [n & 0xff, (n >> 8) & 0xff]; }
  function uint32LE(n) { return [n & 0xff, (n >> 8) & 0xff, (n >> 16) & 0xff, (n >> 24) & 0xff]; }

  const localHeaders = [];
  const centralDirs  = [];
  let offset = 0;
  const allBytes = [];

  for (const [name, content] of Object.entries(files)) {
    const nameBytes    = utf8Encode(name);
    // Binary files (like PNG) are passed as binary strings, not UTF-8 text
    const isBinary = typeof content === 'string' && content.length > 0 &&
                     content.charCodeAt(0) > 127 || (name.endsWith('.png') || name.endsWith('.jpg'));
    const contentBytes = name.match(/.(png|jpg|jpeg|gif)$/i)
      ? strToBytes(content)
      : utf8Encode(content);
    const crc  = crc32(contentBytes);
    const size = contentBytes.length;

    // Local file header
    const local = [
      0x50, 0x4B, 0x03, 0x04, // signature
      0x14, 0x00,              // version 2.0
      0x00, 0x00,              // flags
      0x00, 0x00,              // no compression
      0x00, 0x00, 0x00, 0x00,  // mod time/date
      ...uint32LE(crc),
      ...uint32LE(size),
      ...uint32LE(size),
      ...uint16LE(nameBytes.length),
      0x00, 0x00,              // extra field len
      ...nameBytes,
    ];

    allBytes.push(...local, ...contentBytes);

    // Central directory entry
    centralDirs.push({
      name: nameBytes,
      crc, size, offset,
      local,
    });

    offset += local.length + size;
  }

  const centralStart = offset;
  const cdBytes = [];

  for (const { name, crc, size, offset: fOffset } of centralDirs) {
    cdBytes.push(
      0x50, 0x4B, 0x01, 0x02,  // signature
      0x14, 0x00,               // version made by
      0x14, 0x00,               // version needed
      0x00, 0x00,               // flags
      0x00, 0x00,               // no compression
      0x00, 0x00, 0x00, 0x00,   // mod time/date
      ...uint32LE(crc),
      ...uint32LE(size),
      ...uint32LE(size),
      ...uint16LE(name.length),
      0x00, 0x00,               // extra len
      0x00, 0x00,               // comment len
      0x00, 0x00,               // disk start
      0x00, 0x00,               // internal attrs
      0x00, 0x00, 0x00, 0x00,   // external attrs
      ...uint32LE(fOffset),
      ...name,
    );
  }

  const cdSize = cdBytes.length;
  const eocd = [
    0x50, 0x4B, 0x05, 0x06,  // end of central dir signature
    0x00, 0x00,               // disk number
    0x00, 0x00,               // disk with CD
    ...uint16LE(centralDirs.length),
    ...uint16LE(centralDirs.length),
    ...uint32LE(cdSize),
    ...uint32LE(centralStart),
    0x00, 0x00,               // comment length
  ];

  const zipBytes = new Uint8Array([...allBytes, ...cdBytes, ...eocd]);

  // Convert to base64
  let binary = '';
  for (let i = 0; i < zipBytes.length; i++) binary += String.fromCharCode(zipBytes[i]);
  return btoa(binary);
}

// ── Persistent detached window management ─────────────────────────────────────
// Clicking the toolbar icon creates a real browser window (not a popup).
// This keeps JobFill open while you interact with job-application pages.
let _winId = null;

chrome.action.onClicked.addListener(async () => {
  // Try to focus an already-open window
  if (_winId !== null) {
    try {
      await chrome.windows.update(_winId, { focused: true, state: 'normal' });
      return;
    } catch (_) {
      _winId = null; // window was closed externally
    }
  }
  // Also check storage (survives service-worker restarts)
  const stored = await chrome.storage.local.get('_jfWinId');
  if (stored._jfWinId) {
    try {
      await chrome.windows.update(stored._jfWinId, { focused: true, state: 'normal' });
      _winId = stored._jfWinId;
      return;
    } catch (_) {
      _winId = null;
      chrome.storage.local.remove('_jfWinId');
    }
  }
  // Create a new window — use explicit left/top + state:'normal' to prevent
  // Chrome from restoring a previously maximised state.
  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('popup.html'),
    type: 'popup',
    width: 520,
    height: 760,
    left: 100,
    top:  60,
    state: 'normal',
    focused: true
  });
  _winId = win.id;
  chrome.storage.local.set({ _jfWinId: win.id });
});

// Clean up when the window is closed
chrome.windows.onRemoved.addListener(id => {
  if (id === _winId) {
    _winId = null;
    chrome.storage.local.remove('_jfWinId');
  }
});

// Allow popup.js to request minimize
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'MINIMIZE_WIN') {
    chrome.windows.getCurrent(win => {
      if (win && win.id) chrome.windows.update(win.id, { state: 'minimized' });
    });
    sendResponse({});
  }
});
