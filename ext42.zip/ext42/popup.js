// ── JobFill popup.js ─────────────────────────────────────────────────────────
'use strict';
const $ = id => document.getElementById(id);

// ── TABS ─────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $('panel-' + tab.dataset.tab).classList.add('active');
  });
});

// ── STATE ────────────────────────────────────────────────────────────────────
let experiences = [];
let educations  = [];
let certs       = [];
window._refs    = [];

// ── HELPER: escape HTML for values injected into innerHTML ──────────────────
function esc(v) {
  return String(v || '')
    .replace(/&/g,'&amp;').replace(/"/g,'&quot;')
    .replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── SELECT OPTION BUILDERS ───────────────────────────────────────────────────
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function optMonths(sel) {
  return '<option value="">Month</option>' +
    MONTHS.map((m,i) => `<option value="${i+1}"${sel==i+1?' selected':''}>${m}</option>`).join('');
}
function optDays(sel) {
  let s = '<option value="">Day</option>';
  for (let d=1;d<=31;d++) s += `<option value="${d}"${sel==d?' selected':''}>${d}</option>`;
  return s;
}
function optYears(sel, start=1970, end=new Date().getFullYear()) {
  let s = '<option value="">Year</option>';
  for (let y=end;y>=start;y--) s += `<option value="${y}"${sel==y?' selected':''}>${y}</option>`;
  return s;
}
function optYearsFut(sel) { return optYears(sel, new Date().getFullYear(), new Date().getFullYear()+20); }

// ── Split description into sentences (max 20) ─────────────────────────────────
function splitToSentences(text, max=20) {
  if (!text || !text.trim()) return [];
  // Split on sentence-ending punctuation followed by whitespace/newline,
  // OR on newlines (bullet items already separated by newlines from parser).
  const raw = text
    .replace(/([.!?])\s+/g, '$1\n')  // sentence break → newline
    .split('\n')
    .map(s => s.trim())
    .filter(s => s.length > 1);
  if (raw.length <= max) return raw;
  // If more than max, keep first (max-1) as individual, rest joined into last slot
  const head = raw.slice(0, max - 1);
  const tail = raw.slice(max - 1).join(' ');
  return [...head, tail];
}

// Get active (checked) sentences joined into a paragraph
function activeDescription(exp) {
  if (!exp.sentences || !exp.sentences.length) return exp.description || '';
  const active = exp.sentences
    .filter((s, idx) => exp.sentenceChecked && exp.sentenceChecked[idx] !== false)
    .join(' ');
  return active;
}


// ── EXPERIENCE CARDS ─────────────────────────────────────────────────────────
function renderExperiences() {
  const list = $('experienceList');
  list.innerHTML = '';
  if (experiences.length === 0) {
    list.innerHTML = '<p style="color:var(--text-mu);font-size:12px;font-weight:700;text-align:center;padding:16px 0;">No experience entries yet. Click ＋ below to add one.</p>';
  }
  experiences.forEach((exp, i) => {
    const card = document.createElement('div');
    card.className = 'card exp-card';

    // Build alt title rows (3 titles: primary + 2 alternates, radio = active selection)
    const activeTitleIdx = +(exp.activeTitleIdx ?? 0);
    const titleRows = [0,1,2].map(t => {
      const val = t === 0 ? (exp.title||'') : (exp[`altTitle${t}`]||'');
      const labels = ['Primary', 'Alt 1', 'Alt 2'];
      const placeholder = '';
      return `<div class="alt-title-row">
        <input type="radio" name="activeTitle_${i}" class="ef-title-radio" data-i="${i}" data-t="${t}" ${activeTitleIdx===t?'checked':''}>
        <span class="title-badge">${labels[t]}</span>
        <input type="text" class="ef" data-i="${i}" data-k="${t===0?'title':'altTitle'+t}" value="${t===0?esc(exp.title):esc(exp['altTitle'+t])}" style="flex:1;border-radius:var(--r-sm);padding:6px 9px;border:2px solid var(--border-dk);background:var(--white);color:var(--text);font-family:'Poppins',sans-serif;font-size:12px;font-weight:600;outline:none;" />
      </div>`;
    }).join('');

    // Build sentence checkboxes
    // If sentences not yet split, do it now from description
    if (!exp.sentences || !exp.sentences.length) {
      exp.sentences = splitToSentences(exp.description || '');
      exp.sentenceChecked = exp.sentences.map(() => true);
    }
    // Ensure sentenceChecked array matches sentences length
    if (!exp.sentenceChecked || exp.sentenceChecked.length !== exp.sentences.length) {
      exp.sentenceChecked = exp.sentences.map((_, idx) =>
        exp.sentenceChecked ? (exp.sentenceChecked[idx] !== false) : true
      );
    }

    const nSent = exp.sentences.length;
    const sentRows = exp.sentences.map((s, si) => {
      const checked = exp.sentenceChecked[si] !== false;
      const isFirst = si === 0, isLast = si === nSent - 1;
      return `<div class="sent-item${checked?' checked':''}" data-exp="${i}" data-si="${si}">
        <input type="checkbox" class="ef-sent-ck" data-i="${i}" data-si="${si}" ${checked?'checked':''}>
        <textarea class="ef-sent-txt" data-i="${i}" data-si="${si}" rows="2">${esc(s)}</textarea>
        <div class="sent-ctrl">
          <button class="sent-up"  data-i="${i}" data-si="${si}" title="Move up"   ${isFirst?'disabled':''}>↑</button>
          <button class="sent-dn"  data-i="${i}" data-si="${si}" title="Move down" ${isLast?'disabled':''}>↓</button>
          <button class="sent-del" data-i="${i}" data-si="${si}" title="Delete sentence">✕</button>
        </div>
      </div>`;
    }).join('');

    const expUse = exp.useInFill !== false; // default true
    const collapsed = exp.collapsed === true;
    card.innerHTML = `
      <div class="card-hd">
        <div style="display:flex;align-items:center;gap:8px;">
          <input type="checkbox" class="ef-use" data-i="${i}" ${expUse?'checked':''} title="Include when filling forms" style="width:16px;height:16px;accent-color:var(--green);cursor:pointer;flex-shrink:0;">
          <span class="card-title">Experience #${i+1} ${exp.company ? '— '+esc(exp.company) : ''}</span>
        </div>
        <div style="display:flex;gap:4px;align-items:center;">
          <button class="exp-collapse-btn rm-btn" data-idx="${i}" title="${collapsed?'Expand':'Collapse'}" style="background:var(--blue-lt);color:var(--blue-dk);border-color:var(--blue);">${collapsed?'▼ Show':'▲ Hide'}</button>
          <button class="rm-btn" data-type="exp" data-idx="${i}">✕ Remove</button>
        </div>
      </div>

      <div class="exp-card-body" ${collapsed?'style="display:none"':''}>
      <div class="sec" style="margin-top:0"><span class="sec-ic ic-g">🏢</span>Company</div>
      <div class="fr c2">
        <div class="f"><label>Company Name</label><input class="ef" data-i="${i}" data-k="company" value="${esc(exp.company)}" /></div>
        <div class="f"><label>Company Phone</label><input class="ef" data-i="${i}" data-k="companyPhone" value="${esc(exp.companyPhone)}" /></div>
      </div>
      <div class="sec"><span class="sec-ic ic-b">📍</span>Company Location</div>
      <div class="fr c1"><div class="f"><label>Street Address Line 1</label><input class="ef" data-i="${i}" data-k="compStreet1" value="${esc(exp.compStreet1)}" /></div></div>
      <div class="fr c1"><div class="f"><label>Street Address Line 2</label><input class="ef" data-i="${i}" data-k="compStreet2" value="${esc(exp.compStreet2)}" /></div></div>
      <div class="fr c3">
        <div class="f"><label>City</label><input class="ef" data-i="${i}" data-k="compCity" value="${esc(exp.compCity)}" /></div>
        <div class="f"><label>State</label><input class="ef" data-i="${i}" data-k="compState" value="${esc(exp.compState)}" /></div>
        <div class="f"><label>ZIP Code</label><input class="ef" data-i="${i}" data-k="compZip" value="${esc(exp.compZip)}" /></div>
      </div>
      <div class="fr c1"><div class="f"><label>Country</label><input class="ef" data-i="${i}" data-k="compCountry" value="${esc(exp.compCountry)}" /></div></div>

      <div class="sec"><span class="sec-ic ic-o">💼</span>Job Title
        <span style="font-size:10px;font-weight:600;color:var(--text-mu);margin-left:6px;">● = active title used when filling forms</span>
      </div>
      ${titleRows}
      <div class="fr c2" style="margin-top:8px;">
        <div class="f"><label>Employment Type</label>
          <select class="ef" data-i="${i}" data-k="empType">
            <option value="">— select —</option>
            <option value="Full-time"${exp.empType==='Full-time'?' selected':''}>Full-time</option>
            <option value="Part-time"${exp.empType==='Part-time'?' selected':''}>Part-time</option>
            <option value="Contract"${exp.empType==='Contract'?' selected':''}>Contract</option>
            <option value="Internship"${exp.empType==='Internship'?' selected':''}>Internship</option>
          </select>
        </div>
      </div>

      <div class="sec"><span class="sec-ic ic-p">📅</span>Dates</div>
      <div class="fr c2">
        <div class="f"><label>Start Date</label>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;">
            <select class="ef" data-i="${i}" data-k="startMonth">${optMonths(exp.startMonth)}</select>
            <select class="ef" data-i="${i}" data-k="startDay">${optDays(exp.startDay)}</select>
            <select class="ef" data-i="${i}" data-k="startYear">${optYears(exp.startYear)}</select>
          </div>
        </div>
        <div class="f"><label>End Date</label>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:4px;">
            <select class="ef ef-end" data-i="${i}" data-k="endMonth" ${exp.present?'disabled':''} style="opacity:${exp.present?.4:1}">${optMonths(exp.endMonth)}</select>
            <select class="ef ef-end" data-i="${i}" data-k="endDay"   ${exp.present?'disabled':''} style="opacity:${exp.present?.4:1}">${optDays(exp.endDay)}</select>
            <select class="ef ef-end" data-i="${i}" data-k="endYear"  ${exp.present?'disabled':''} style="opacity:${exp.present?.4:1}">${optYears(exp.endYear)}</select>
          </div>
          <div class="ck-row">
            <input type="checkbox" id="present_${i}" class="ef-present" data-i="${i}" ${exp.present?'checked':''}>
            <label for="present_${i}">Currently working here (Present)</label>
          </div>
        </div>
      </div>

      <div class="sec"><span class="sec-ic ic-p">📝</span>Description / Achievements
        <span style="font-size:10px;font-weight:600;color:var(--text-mu);margin-left:6px;">✓ = include · ↑↓ reorder · ✕ delete</span>
      </div>
      <div class="sent-list" id="sent_${i}">
        ${sentRows || '<p style="color:var(--text-mu);font-size:11px;font-weight:700;padding:6px 0;">No description yet — type or import one.</p>'}
      </div>
      <button class="add-btn" style="margin-top:6px;font-size:11px;padding:6px;" data-add-sent="${i}">＋ Add sentence</button>
      </div>
    `;
    list.appendChild(card);
  });
  attachListeners();
}

// ── EDUCATION CARDS ───────────────────────────────────────────────────────────
function renderEducations() {
  const list = $('educationList');
  list.innerHTML = '';
  if (educations.length === 0) {
    list.innerHTML = '<p style="color:var(--text-mu);font-size:12px;font-weight:700;text-align:center;padding:16px 0;">No education entries yet. Click ＋ below to add one.</p>';
  }
  educations.forEach((edu, i) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-hd">
        <span class="card-title">Education #${i+1} ${edu.school ? '— '+esc(edu.school) : ''}</span>
        <button class="rm-btn" data-type="edu" data-idx="${i}">✕ Remove</button>
      </div>
      <div class="fr c1"><div class="f"><label>School / University</label><input class="edf" data-i="${i}" data-k="school" value="${esc(edu.school)}" /></div></div>
      <div class="fr c2">
        <div class="f"><label>Degree</label><input class="edf" data-i="${i}" data-k="degree" value="${esc(edu.degree)}" /></div>
        <div class="f"><label>Field of Study</label><input class="edf" data-i="${i}" data-k="field" value="${esc(edu.field)}" /></div>
      </div>
      <div class="fr c3">
        <div class="f"><label>Start Year</label>
          <select class="edf" data-i="${i}" data-k="startYear">${optYears(edu.startYear)}</select>
        </div>
        <div class="f"><label>Graduation Year</label>
          <select class="edf" data-i="${i}" data-k="gradYear">${optYears(edu.gradYear)}</select>
        </div>
        <div class="f"><label>GPA (optional)</label>
          <input class="edf" data-i="${i}" data-k="gpa" value="${esc(edu.gpa)}" />
        </div>
      </div>
      <div class="fr c1"><div class="f"><label>Misc / Honors</label><input class="edf" data-i="${i}" data-k="miscData" placeholder="e.g. Summa Cum Laude, Dean's List" value="${esc(edu.miscData)}" /></div></div>
      <div class="ck-row">
        <input type="checkbox" id="fin_${i}" class="edf-ck" data-i="${i}" data-k="finished" ${edu.finished?'checked':''}>
        <label for="fin_${i}">Finished / Graduated</label>
      </div>
    `;
    list.appendChild(card);
  });
  attachListeners();
}

// ── CERT CARDS ────────────────────────────────────────────────────────────────
function renderCerts() {
  const list = $('certsList');
  list.innerHTML = '';
  if (certs.length === 0) {
    list.innerHTML = '<p style="color:var(--text-mu);font-size:12px;font-weight:700;text-align:center;padding:16px 0;">No certifications yet. Click ＋ below to add one.</p>';
  }
  certs.forEach((c, i) => {
    const card = document.createElement('div');
    card.className = 'card';
    const certUse = c.useInFill !== false; // default true
    card.innerHTML = `
      <div class="card-hd">
        <div style="display:flex;align-items:center;gap:8px;">
          <input type="checkbox" class="cf-use" data-i="${i}" ${certUse?'checked':''} title="Include when filling forms" style="width:16px;height:16px;accent-color:var(--green);cursor:pointer;flex-shrink:0;">
          <span class="card-title">Cert #${i+1} ${c.name ? '— '+esc(c.name) : ''}</span>
        </div>
        <div style="display:flex;align-items:center;gap:4px;">
          ${i > 0 ? `<button class="rm-btn cert-move-up" data-idx="${i}" title="Move up">▲</button>` : ''}
          ${i < certs.length-1 ? `<button class="rm-btn cert-move-dn" data-idx="${i}" title="Move down">▼</button>` : ''}
          <button class="rm-btn" data-type="cert" data-idx="${i}">✕ Remove</button>
        </div>
      </div>
      <div class="fr c2">
        <div class="f"><label>Type</label>
          <select class="cf" data-i="${i}" data-k="certType">
            <option value="Certification" ${(c.certType||'Certification')==='Certification'?'selected':''}>Certification</option>
            <option value="Course" ${c.certType==='Course'?'selected':''}>Course</option>
          </select>
        </div>
        <div class="f"><label>${'Cert/Course'} Name</label><input class="cf" data-i="${i}" data-k="name" value="${esc(c.name)}" /></div>
      </div>
      <div class="fr c2">
        <div class="f"><label>Issuing Authority</label><input class="cf" data-i="${i}" data-k="authority" value="${esc(c.authority)}" /></div>
        <div class="f"><label>Certificate Number</label><input class="cf" data-i="${i}" data-k="certNum" value="${esc(c.certNum)}" /></div>
      </div>
      <div class="fr c2" style="margin-top:4px;">
        <div class="ck-row"><input type="checkbox" id="cc_${i}" class="cf-ck" data-i="${i}" data-k="current" ${c.current?'checked':''}><label for="cc_${i}">Currently Active</label></div>
      </div>
      <div class="fr c2">
        <div class="f"><label>Date Completed</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;">
            <select class="cf" data-i="${i}" data-k="completedMonth">${optMonths(c.completedMonth)}</select>
            <select class="cf" data-i="${i}" data-k="completedYear">${optYears(c.completedYear)}</select>
          </div>
        </div>
        <div class="f"><label>Expiry Date</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;">
            <select class="cf" data-i="${i}" data-k="expiresMonth">${optMonths(c.expiresMonth)}</select>
            <select class="cf" data-i="${i}" data-k="expiresYear">${optYearsFut(c.expiresYear)}</select>
          </div>
        </div>
      </div>
    `;
    list.appendChild(card);
  });
  attachListeners();
}

// ── REFERENCE CARDS ───────────────────────────────────────────────────────────
function renderRefs() {
  const list = $('refList');
  list.innerHTML = '';
  if (!window._refs || window._refs.length === 0) window._refs = [{},{},{}];
  window._refs.forEach((ref, i) => {
    const refUse = ref.useInFill !== false; // default true
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-hd">
        <div style="display:flex;align-items:center;gap:8px;">
          <input type="checkbox" class="rf-use" data-i="${i}" ${refUse?'checked':''} title="Include when filling forms" style="width:16px;height:16px;accent-color:var(--green);cursor:pointer;flex-shrink:0;">
          <span class="card-title">Reference ${i+1} ${ref.name ? '— '+esc(ref.name) : ''}</span>
        </div>
        <div style="display:flex;align-items:center;gap:4px;">
          ${i > 0 ? `<button class="rm-btn ref-move-up" data-idx="${i}" title="Move up">▲</button>` : ''}
          ${i < window._refs.length-1 ? `<button class="rm-btn ref-move-dn" data-idx="${i}" title="Move down">▼</button>` : ''}
          <button class="rm-btn" data-type="ref" data-idx="${i}">✕ Remove</button>
        </div>
      </div>
      <div class="fr c2">
        <div class="f"><label>Full Name</label><input class="rf" data-i="${i}" data-k="name" value="${esc(ref.name)}" /></div>
        <div class="f"><label>Title / Position</label><input class="rf" data-i="${i}" data-k="title" value="${esc(ref.title)}" /></div>
      </div>
      <div class="fr c2">
        <div class="f"><label>Company / Organization</label><input class="rf" data-i="${i}" data-k="company" value="${esc(ref.company)}" /></div>
        <div class="f"><label>Phone Number</label><input class="rf" data-i="${i}" data-k="phone" value="${esc(ref.phone)}" /></div>
      </div>
      <div class="fr c1">
        <div class="f"><label>Email Address</label><input class="rf" data-i="${i}" data-k="email" type="email" value="${esc(ref.email)}" /></div>
      </div>
    `;
    list.appendChild(card);
  });
  attachListeners();
}

// ── EVENT DELEGATION ──────────────────────────────────────────────────────────
function attachListeners() {
  // ── Remove buttons ──────────────────────────────────────────────────────────
  document.querySelectorAll('.rm-btn').forEach(btn => {
    btn.onclick = () => {
      const idx = parseInt(btn.dataset.idx);
      if (btn.dataset.type === 'exp')  { experiences.splice(idx,1); renderExperiences(); }
      if (btn.dataset.type === 'edu')  { educations.splice(idx,1);  renderEducations(); }
      if (btn.dataset.type === 'cert') { certs.splice(idx,1);       renderCerts(); }
      if (btn.dataset.type === 'ref')  { window._refs.splice(idx,1); renderRefs(); }
    };
  });

  // ── Experience card collapse/expand ────────────────────────────────────────
  document.querySelectorAll('.exp-collapse-btn').forEach(btn => {
    btn.onclick = () => {
      const idx = +btn.dataset.idx;
      experiences[idx].collapsed = !experiences[idx].collapsed;
      renderExperiences();
    };
  });
  // useInFill checkboxes
  document.querySelectorAll('.ef-use').forEach(el => {
    el.onchange = () => { experiences[+el.dataset.i].useInFill = el.checked; };
  });
  document.querySelectorAll('.cf-use').forEach(el => {
    el.onchange = () => { certs[+el.dataset.i].useInFill = el.checked; };
  });
  document.querySelectorAll('.rf-use').forEach(el => {
    el.onchange = () => { window._refs[+el.dataset.i].useInFill = el.checked; };
  });

  // ── Experience standard fields ──────────────────────────────────────────────
  document.querySelectorAll('.ef').forEach(el => {
    el.oninput  = () => { if(el.dataset.k) experiences[+el.dataset.i][el.dataset.k] = el.value; };
    el.onchange = () => { if(el.dataset.k) experiences[+el.dataset.i][el.dataset.k] = el.value; };
  });
  document.querySelectorAll('.ef-present').forEach(el => {
    el.onchange = () => { experiences[+el.dataset.i].present = el.checked; renderExperiences(); };
  });

  // ── Alt title radio buttons ─────────────────────────────────────────────────
  document.querySelectorAll('.ef-title-radio').forEach(el => {
    el.onchange = () => {
      experiences[+el.dataset.i].activeTitleIdx = +el.dataset.t;
    };
  });

  // ── Sentence checkboxes ─────────────────────────────────────────────────────
  document.querySelectorAll('.ef-sent-ck').forEach(el => {
    el.onchange = () => {
      const i = +el.dataset.i;
      const si = +el.dataset.si;
      if (!experiences[i].sentenceChecked) experiences[i].sentenceChecked = [];
      experiences[i].sentenceChecked[si] = el.checked;
      // Toggle visual highlight
      const item = el.closest('.sent-item');
      if (item) item.classList.toggle('checked', el.checked);
    };
  });

  // ── Sentence text edits ─────────────────────────────────────────────────────
  document.querySelectorAll('.ef-sent-txt').forEach(el => {
    el.oninput = () => {
      const i = +el.dataset.i;
      const si = +el.dataset.si;
      if (experiences[i].sentences) experiences[i].sentences[si] = el.value;
    };
  });

  // ── Sentence delete ─────────────────────────────────────────────────────────
  document.querySelectorAll('.sent-del').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.i, si = +btn.dataset.si;
      experiences[i].sentences.splice(si, 1);
      experiences[i].sentenceChecked.splice(si, 1);
      renderExperiences();
    };
  });

  // ── Sentence move up/down ───────────────────────────────────────────────────
  document.querySelectorAll('.sent-up').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.i, si = +btn.dataset.si;
      if (si === 0) return;
      [experiences[i].sentences[si-1], experiences[i].sentences[si]] =
        [experiences[i].sentences[si], experiences[i].sentences[si-1]];
      [experiences[i].sentenceChecked[si-1], experiences[i].sentenceChecked[si]] =
        [experiences[i].sentenceChecked[si], experiences[i].sentenceChecked[si-1]];
      renderExperiences();
    };
  });
  document.querySelectorAll('.sent-dn').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.i, si = +btn.dataset.si;
      const last = experiences[i].sentences.length - 1;
      if (si >= last) return;
      [experiences[i].sentences[si+1], experiences[i].sentences[si]] =
        [experiences[i].sentences[si], experiences[i].sentences[si+1]];
      [experiences[i].sentenceChecked[si+1], experiences[i].sentenceChecked[si]] =
        [experiences[i].sentenceChecked[si], experiences[i].sentenceChecked[si+1]];
      renderExperiences();
    };
  });

  // ── Add sentence buttons ────────────────────────────────────────────────────
  document.querySelectorAll('[data-add-sent]').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.addSent;
      if (!experiences[i].sentences) experiences[i].sentences = [];
      experiences[i].sentences.push('');
      if (!experiences[i].sentenceChecked) experiences[i].sentenceChecked = [];
      experiences[i].sentenceChecked.push(true);
      renderExperiences();
    };
  });

  // ── Education ───────────────────────────────────────────────────────────────
  document.querySelectorAll('.edf').forEach(el => {
    el.oninput  = () => { educations[+el.dataset.i][el.dataset.k] = el.value; };
    el.onchange = () => { educations[+el.dataset.i][el.dataset.k] = el.value; };
  });
  document.querySelectorAll('.edf-ck').forEach(el => {
    el.onchange = () => { educations[+el.dataset.i][el.dataset.k] = el.checked; };
  });

  // ── Certs ───────────────────────────────────────────────────────────────────
  document.querySelectorAll('.cf').forEach(el => {
    el.oninput  = () => { certs[+el.dataset.i][el.dataset.k] = el.value; };
    el.onchange = () => { certs[+el.dataset.i][el.dataset.k] = el.value; };
  });
  document.querySelectorAll('.cf-ck').forEach(el => {
    el.onchange = () => { certs[+el.dataset.i][el.dataset.k] = el.checked; };
  });

  // ── Cert move up/down ───────────────────────────────────────────────────────
  document.querySelectorAll('.cert-move-up').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.idx;
      if (i === 0) return;
      [certs[i-1], certs[i]] = [certs[i], certs[i-1]];
      renderCerts();
    };
  });
  document.querySelectorAll('.cert-move-dn').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.idx;
      if (i >= certs.length - 1) return;
      [certs[i+1], certs[i]] = [certs[i], certs[i+1]];
      renderCerts();
    };
  });

  // ── Ref move up/down ────────────────────────────────────────────────────────
  document.querySelectorAll('.ref-move-up').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.idx;
      if (i === 0) return;
      [window._refs[i-1], window._refs[i]] = [window._refs[i], window._refs[i-1]];
      renderRefs();
    };
  });
  document.querySelectorAll('.ref-move-dn').forEach(btn => {
    btn.onclick = () => {
      const i = +btn.dataset.idx;
      if (i >= window._refs.length - 1) return;
      [window._refs[i+1], window._refs[i]] = [window._refs[i], window._refs[i+1]];
      renderRefs();
    };
  });

  // ── References ──────────────────────────────────────────────────────────────
  document.querySelectorAll('.rf').forEach(el => {
    el.oninput = () => { window._refs[+el.dataset.i][el.dataset.k] = el.value; };
  });
}

$('addExperience').onclick = () => { experiences.push({}); renderExperiences(); };
$('addEducation').onclick  = () => { educations.push({});  renderEducations(); };
$('addCert').onclick       = () => { certs.push({});        renderCerts(); };
$('addRef').onclick        = () => { if(window._refs.length < 10) { window._refs.push({}); renderRefs(); } else showToast('Maximum 10 references','r'); };

// ── FLAT FIELD IDs ────────────────────────────────────────────────────────────
const PERSONAL_IDS  = ['firstName','lastName','middleName','email','phone','linkedin','website','github','workAuth','sponsorship','salary','yearsExp','gender','raceEthnicity'];
// Checkbox fields within personal (stored as booleans, default true)
const PERSONAL_CK_IDS = ['linkedinUse','websiteUse','githubUse'];
const LOCATION_IDS  = ['street1','street2','city','state','zip','country'];
const COVER_IDS     = ['coverLetter','whyRole','aboutMe','strength','weakness','hearAbout'];
// Overview and Skills are structured arrays (3 entries each with text + useInFill)
let overviews = [{text:'',useInFill:true},{text:'',useInFill:false},{text:'',useInFill:false}];
let skillSets = [{text:'',useInFill:true},{text:'',useInFill:false},{text:'',useInFill:false}];

// Ensure overview/skill arrays always have exactly 3 slots
function padArr(arr, dflt) {
  const a = arr ? arr.slice() : [];
  while (a.length < 3) a.push({ ...dflt });
  return a;
}

// ── OVERVIEW / SKILLS RENDERERS ──────────────────────────────────────────────
function renderOverviews() {
  const list = $('overviewList');
  if (!list) return;
  list.innerHTML = '';
  const labels = ['Primary', 'Alt 1', 'Alt 2'];
  const ph = ['', '', ''];
  overviews.forEach((ov, i) => {
    const div = document.createElement('div');
    div.className = 'ov-row' + (ov.useInFill ? ' checked' : '');
    div.innerHTML = `
      <input type="checkbox" class="ov-ck" data-i="${i}" ${ov.useInFill ? 'checked' : ''} title="Use when filling forms">
      <span class="ov-row-label">${labels[i]}</span>
      <textarea class="ov-txt" data-i="${i}" rows="4">${esc(ov.text)}</textarea>`;
    list.appendChild(div);
  });
  // wire listeners
  list.querySelectorAll('.ov-ck').forEach(el => {
    el.onchange = () => {
      overviews[+el.dataset.i].useInFill = el.checked;
      el.closest('.ov-row').classList.toggle('checked', el.checked);
    };
  });
  list.querySelectorAll('.ov-txt').forEach(el => {
    el.oninput = () => { overviews[+el.dataset.i].text = el.value; };
  });
}

function renderSkills() {
  const list = $('skillsList');
  if (!list) return;
  list.innerHTML = '';
  const labels = ['Primary', 'Alt 1', 'Alt 2'];
  const ph = ['', '', ''];
  skillSets.forEach((sk, i) => {
    const div = document.createElement('div');
    div.className = 'ov-row' + (sk.useInFill ? ' checked' : '');
    div.innerHTML = `
      <input type="checkbox" class="sk-ck" data-i="${i}" ${sk.useInFill ? 'checked' : ''} title="Use when filling forms">
      <span class="ov-row-label">${labels[i]}</span>
      <textarea class="sk-txt" data-i="${i}" rows="3">${esc(sk.text)}</textarea>`;
    list.appendChild(div);
  });
  list.querySelectorAll('.sk-ck').forEach(el => {
    el.onchange = () => {
      skillSets[+el.dataset.i].useInFill = el.checked;
      el.closest('.ov-row').classList.toggle('checked', el.checked);
    };
  });
  list.querySelectorAll('.sk-txt').forEach(el => {
    el.oninput = () => { skillSets[+el.dataset.i].text = el.value; };
  });
}

// ── COLLECT ───────────────────────────────────────────────────────────────────
function collectAll() {
  const personal={}, location={}, cover={};
  PERSONAL_IDS.forEach(id => { if($(id)) personal[id]=$(id).value; });
  PERSONAL_CK_IDS.forEach(id => { if($(id)) personal[id]=$(id).checked; });
  LOCATION_IDS.forEach(id => { if($(id)) location[id]=$(id).value; });
  COVER_IDS.forEach(id => { if($(id)) cover[id]=$(id).value; });
  return { personal, location, experiences, educations, certs, refs:window._refs, cover, overviews, skillSets };
}

// ── LOAD FROM STORAGE ─────────────────────────────────────────────────────────
let _storageLoaded = false;
let _pendingImport = null;  // holds { map } if import arrived before storage load

chrome.storage.local.get(['personal','location','experiences','educations','certs','refs','cover','overviews','skillSets'], d => {
  // Only apply stored data if no import has already run
  if (!_pendingImport) {
    if (d.personal) {
      PERSONAL_IDS.forEach(id => { if($(id)&&d.personal[id]) $(id).value=d.personal[id]; });
      PERSONAL_CK_IDS.forEach(id => { if($(id)) $(id).checked = d.personal[id] !== false; }); // default true
    }
    if (d.location) LOCATION_IDS.forEach(id => { if($(id)&&d.location[id]) $(id).value=d.location[id]; });
    if (d.cover)    COVER_IDS.forEach(id => { if($(id)&&d.cover[id]) $(id).value=d.cover[id]; });
    if (d.overviews?.length)  overviews  = padArr(d.overviews,  {text:'',useInFill:false});
    if (d.skillSets?.length)  skillSets  = padArr(d.skillSets, {text:'',useInFill:false});
    renderOverviews();
    renderSkills();
    if (d.experiences?.length) { experiences=d.experiences; } renderExperiences();
    if (d.educations?.length)  { educations=d.educations;  } renderEducations();
    if (d.certs?.length)       { certs=d.certs;            } renderCerts();
    if (d.refs && d.refs.length) window._refs=d.refs;
    if (!window._refs || !window._refs.length) window._refs=[{},{},{}];
    renderRefs();
  } else {
    // Import already ran before storage loaded — apply the pending import now
    applyImportData(buildFromMap(_pendingImport), { overwrite: true });
    _pendingImport = null;
  }
  _storageLoaded = true;
});

// ── SAVE ──────────────────────────────────────────────────────────────────────
function saveAll(cb) { chrome.storage.local.set(collectAll(), cb || (()=>{})); }

// ── AUTOSAVE — fires whenever the popup loses focus or is closed ──────────────
// 'visibilitychange' fires when Chrome hides the popup (user clicks away)
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveAll(); });
// 'blur' on window catches edge cases (e.g. switching windows)
window.addEventListener('blur', () => saveAll());

$('saveBtn').onclick = () => {
  saveAll(() => {
    showToast('✓ Saved!','g');
    $('saveBtn').textContent = '✓ Saved';
    setTimeout(()=>{ $('saveBtn').textContent='💾 Save'; }, 2000);
  });
};

// ── FILL PAGE ─────────────────────────────────────────────────────────────────
function triggerFill() {
  saveAll(() => {
    chrome.tabs.query({ active:true, currentWindow:true }, tabs => {
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id, { action:'FILL_FORM', data:collectAll() }, resp => {
        if (chrome.runtime.lastError) {
          chrome.scripting.executeScript({ target:{tabId:tabs[0].id}, files:['content.js'] }, () => {
            chrome.tabs.sendMessage(tabs[0].id, { action:'FILL_FORM', data:collectAll() }, handleResp);
          });
        } else { handleResp(resp); }
      });
    });
  });
}
[$('fillBtnTop'), $('mainFillBtn')].forEach(b => b && (b.onclick = triggerFill));

// ── Minimize button — minimize the detached window ────────────────────────────
if ($('minimizeBtn')) {
  $('minimizeBtn').onclick = () => {
    chrome.windows.getCurrent(win => {
      if (win && win.id) chrome.windows.update(win.id, { state: 'minimized' });
    });
  };
}

function handleResp(resp) {
  if (!resp) { $('statusText').textContent = 'Could not connect to page — try refreshing it'; return; }
  if (resp.filled > 0) {
    showToast(`⚡ ${resp.filled} field${resp.filled!==1?'s':''} filled!`, 'g');
    $('statusText').textContent = `Filled ${resp.filled} field${resp.filled!==1?'s':''} on this page`;
  } else {
    $('statusText').textContent = 'No matching fields found on this page';
  }
  if (resp.unfilled?.length) showErrorQueue(resp.unfilled);
}

// ── ERROR MODAL QUEUE ─────────────────────────────────────────────────────────
let _queue = [];
function showErrorQueue(list) { _queue = [...list]; showNext(); }

function showNext() {
  if (!_queue.length) { $('errorModal').classList.remove('show'); return; }
  const item = _queue[0];
  $('moField').textContent = `Field: "${item.label}"`;
  $('moInput').style.display = 'none'; $('moInput').value = '';
  $('moSubmit').style.display = 'none';
  $('moManual').style.display = '';
  $('moGuess').style.display  = item.guess ? '' : 'none';
  $('moCtr').textContent = _queue.length > 1 ? `${_queue.length} field${_queue.length>1?'s':''} remaining` : '';
  $('errorModal').classList.add('show');
}

$('moSkip').onclick   = () => { _queue.shift(); showNext(); };
$('moManual').onclick = () => {
  $('moManual').style.display = 'none';
  $('moGuess').style.display  = 'none';
  $('moInput').style.display  = '';
  $('moSubmit').style.display = '';
  $('moInput').focus();
};
$('moSubmit').onclick = () => {
  const val = $('moInput').value.trim();
  if (!val) return;
  const item = _queue.shift();
  chrome.tabs.query({ active:true, currentWindow:true }, tabs => {
    if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action:'FILL_ONE', elementId:item.elementId, value:val });
  });
  showNext();
};
$('moGuess').onclick = () => {
  const item = _queue.shift();
  if (item.guess) {
    chrome.tabs.query({ active:true, currentWindow:true }, tabs => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action:'FILL_ONE', elementId:item.elementId, value:item.guess });
    });
    showToast(`🤔 Used: "${String(item.guess).substring(0,28)}"`, 'g');
  }
  showNext();
};

// ── RESUME UPLOAD — click + drag-and-drop ────────────────────────────────────
const uploadZone = $('uploadZone');

// Click to browse
uploadZone.addEventListener('click', () => $('resumeFileInput').click());

// Drag-and-drop: prevent browser from navigating away
uploadZone.addEventListener('dragover', e => {
  e.preventDefault();
  e.stopPropagation();
  uploadZone.style.borderColor = 'var(--green)';
  uploadZone.style.background  = 'var(--green-lt)';
});
uploadZone.addEventListener('dragleave', e => {
  e.preventDefault();
  e.stopPropagation();
  uploadZone.style.borderColor = 'var(--blue)';
  uploadZone.style.background  = 'var(--blue-lt)';
});
uploadZone.addEventListener('drop', e => {
  e.preventDefault();
  e.stopPropagation();
  uploadZone.style.borderColor = 'var(--blue)';
  uploadZone.style.background  = 'var(--blue-lt)';
  const file = e.dataTransfer?.files?.[0];
  if (file) handleResumeFile(file);
});

// File input change
$('resumeFileInput').addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) handleResumeFile(file);
  // Reset so same file can be re-selected
  e.target.value = '';
});

function handleResumeFile(file) {
  const name = file.name.toLowerCase();
  showParseOk('⏳ Reading file…');

  if (name.endsWith('.json')) {
    readAsText(file, text => {
      try { applyImportData(JSON.parse(text)); showParseOk('✓ JSON resume imported!'); }
      catch(err) { showParseOk('⚠ JSON parse error: ' + err.message, true); }
    });

  } else if (name.endsWith('.txt')) {
    readAsText(file, text => parseTextResume(text, '.txt'));

  } else if (name.endsWith('.docx')) {
    // .docx is a ZIP containing word/document.xml — parse that XML directly
    readAsArrayBuffer(file, buf => {
      extractDocxText(buf)
        .then(({ text, hyperlinkURLs }) => parseTextResume(text, '.docx', hyperlinkURLs))
        .catch(err => showParseOk('⚠ .docx read error: ' + err.message, true));
    });

  } else if (name.endsWith('.xml')) {
    readAsText(file, text => {
      const plain = xmlToPlainText(text);
      parseTextResume(plain, '.xml');
    });

  } else if (name.endsWith('.rtf')) {
    readAsText(file, text => {
      const plain = rtfToPlainText(text);
      parseTextResume(plain, '.rtf');
    });

  } else {
    showParseOk('⚠ Unsupported format. Please use .docx, .xml, .rtf, .txt, or .json', true);
  }
}

// ── File readers ─────────────────────────────────────────────────────────────
function readAsText(file, cb) {
  const r = new FileReader();
  r.onload  = e => cb(e.target.result);
  r.onerror = () => showParseOk('⚠ Could not read file.', true);
  r.readAsText(file);
}
function readAsArrayBuffer(file, cb) {
  const r = new FileReader();
  r.onload  = e => cb(e.target.result);
  r.onerror = () => showParseOk('⚠ Could not read file.', true);
  r.readAsArrayBuffer(file);
}

// ── .docx → plain text (native, no external library) ─────────────────────────
// A .docx file is a ZIP archive. We unzip it using DecompressionStream (built
// into Chrome 80+) to reach word/document.xml, then strip XML tags.
async function extractDocxText(arrayBuffer) {
  // The ZIP central directory is at the end; we need to find each file entry.
  // We use a simple local-file-header walker (no library needed for our use case).
  const bytes = new Uint8Array(arrayBuffer);

  // Find all local file headers (PK\x03\x04)
  const entries = [];
  for (let i = 0; i < bytes.length - 30; i++) {
    if (bytes[i]===0x50 && bytes[i+1]===0x4B && bytes[i+2]===0x03 && bytes[i+3]===0x04) {
      const compression  = bytes[i+8]  | (bytes[i+9]  << 8);
      const compSize     = bytes[i+18] | (bytes[i+19] << 8) | (bytes[i+20] << 16) | (bytes[i+21] << 24);
      const uncompSize   = bytes[i+22] | (bytes[i+23] << 8) | (bytes[i+24] << 16) | (bytes[i+25] << 24);
      const nameLen      = bytes[i+26] | (bytes[i+27] << 8);
      const extraLen     = bytes[i+28] | (bytes[i+29] << 8);
      const nameBytes    = bytes.slice(i+30, i+30+nameLen);
      const name         = new TextDecoder().decode(nameBytes);
      const dataStart    = i + 30 + nameLen + extraLen;
      const compData     = bytes.slice(dataStart, dataStart + compSize);
      entries.push({ name, compression, compData, uncompSize });
      i = dataStart + compSize - 1;
    }
  }

  // Find word/document.xml
  const docEntry = entries.find(e =>
    e.name === 'word/document.xml' || e.name.endsWith('/document.xml')
  );
  if (!docEntry) throw new Error('Could not find document.xml inside .docx');

  let xmlText;
  if (docEntry.compression === 0) {
    // Stored (uncompressed)
    xmlText = new TextDecoder().decode(docEntry.compData);
  } else if (docEntry.compression === 8) {
    // Deflate — use DecompressionStream (built into Chrome)
    const ds = new DecompressionStream('deflate-raw');
    const writer = ds.writable.getWriter();
    const reader = ds.readable.getReader();
    writer.write(docEntry.compData);
    writer.close();
    const chunks = [];
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    const total = chunks.reduce((n, c) => n + c.length, 0);
    const out   = new Uint8Array(total);
    let offset  = 0;
    for (const c of chunks) { out.set(c, offset); offset += c.length; }
    xmlText = new TextDecoder().decode(out);
  } else {
    throw new Error('Unsupported compression method: ' + docEntry.compression);
  }

  return xmlToPlainTextEx(xmlText);
}

// ── XML → plain text ──────────────────────────────────────────────────────────
// Also extracts hyperlink URLs from instrText and returns them separately.
// Returns { text: string, hyperlinkURLs: string[] }
function xmlToPlainTextEx(xml) {
  // Step 1: collect all HYPERLINK URLs from instrText before stripping
  const hyperlinkURLs = [];
  const instrRE = /<w:instrText[^>]*>([\s\S]*?)<\/w:instrText>/gi;
  let instrM;
  while ((instrM = instrRE.exec(xml)) !== null) {
    const content = instrM[1].trim();
    const hm = content.match(/HYPERLINK\s+"([^"]+)"/i);
    if (hm) hyperlinkURLs.push(hm[1]);
  }

  const text = xml
    .replace(/<w:instrText[^>]*>.*?<\/w:instrText>/gis, '')  // strip field instructions
    .replace(/<w:fldChar[^>]*\/>/gi, '')                     // strip field char markers
    .replace(/<w:tab[^>]*\/>/gi, ' ')                        // <w:tab/> → space (preserves word separation)
    .replace(/<\/w:p>/gi,  '\n')   // paragraph end → newline
    .replace(/(<br)[^>]*(>)/gi, '\n')
    .replace(/<\/p>/gi,    '\n')
    .replace(/<[^>]+>/g,   '')     // strip all remaining tags
    .replace(/&amp;/g,  '&')
    .replace(/&lt;/g,   '<')
    .replace(/&gt;/g,   '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/[ \t]{2,}/g, ' ')   // collapse multiple spaces
    .replace(/\n{3,}/g,    '\n\n') // collapse blank lines
    .trim();

  return { text, hyperlinkURLs };
}

function xmlToPlainText(xml) {
  return xmlToPlainTextEx(xml).text;
}

// ── RTF → plain text ──────────────────────────────────────────────────────────
function rtfToPlainText(rtf) {
  // Remove RTF control words, groups, and binary blobs; keep readable text
  return rtf
    .replace(/\{[^{}]*\}/g,        '')   // remove simple groups first
    .replace(/\\[\*]?[a-z]+[-]?\d* ?/g, '') // control words like \par \pard \b0
    .replace(/\\'[0-9a-f]{2}/gi,   ' ')  // hex-encoded chars → space (simplification)
    .replace(/[{}\\]/g,            '')   // leftover braces and backslashes
    .replace(/[ \t]{2,}/g,         ' ')
    .replace(/\n{3,}/g,            '\n\n')
    .trim();
}

// ══════════════════════════════════════════════════════════════════════════════
// FULL RESUME PARSER v4
// Strategy: Label-first parsing. Every meaningful datum in this resume is
// preceded by a "Label:" cue. We scan for those cues and route accordingly.
// Also supports plain-text resumes with date-range-based job splitting.
// ══════════════════════════════════════════════════════════════════════════════

const MONTH_NAMES = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
function monthIndex(str) {
  const s = (str||'').toLowerCase().substring(0,3);
  const i = MONTH_NAMES.indexOf(s);
  return i >= 0 ? i + 1 : null;
}

// Parse date strings like "November 1st, 2024", "May 2019", "05/14/2013", "2019"
// When a month is found but no day, default day = 1 (per user request).
function parseDateStr(str) {
  const s = (str||'').replace(/\b(\d+)(st|nd|rd|th)\b/gi,'$1').trim();
  let m;
  // "Month Day, Year" e.g. "November 1, 2024"
  m = s.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\b/i);
  if (m) return { month: monthIndex(m[1]), day: parseInt(m[2]), year: m[3] };
  // "Month Year" e.g. "November 2024" — default day=1
  m = s.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{4})\b/i);
  if (m) return { month: monthIndex(m[1]), day: 1, year: m[2] };
  // MM/DD/YYYY e.g. "05/14/2013"
  m = s.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (m) return { month: parseInt(m[1]), day: parseInt(m[2]), year: m[3] };
  // MM/YYYY e.g. "05/2013" — default day=1
  m = s.match(/\b(\d{1,2})\/(\d{4})\b/);
  if (m) return { month: parseInt(m[1]), day: 1, year: m[2] };
  // Year only
  m = s.match(/\b(\d{4})\b/);
  if (m) return { year: m[1] };
  return {};
}

// Parse "City, State" or "City, ST ZIP" from a location string
function parseLocation(str) {
  const s = (str||'').trim();
  const m = s.match(/^([A-Za-z][A-Za-z\s.]+?),\s*([A-Za-z]{2,})\s*(\d{5})?/);
  if (m) return { city: m[1].trim(), state: m[2].trim(), zip: m[3] || '' };
  return { city: s };
}

// Extract a Label: Value pair from a line. Returns {label, value} or null.
function extractLabel(line) {
  // Matches "Some Label: value text" or "Some Label:  value text"
  const m = line.match(/^([A-Za-z][A-Za-z\s\/()]{0,40}?)\s*:\s*(.*)/);
  if (!m) return null;
  return { label: m[1].trim().toLowerCase(), value: m[2].trim() };
}

function parseTextResume(text, format, hyperlinkURLs) {
  hyperlinkURLs = hyperlinkURLs || [];
  const data = {
    personal: {}, location: {}, cover: {},
    experiences: [], educations: [], certs: [], refs: [{},{},{}],
    overviews: [], skillSets: []   // populated below when found in resume
  };

  // ── 1. Extract name — try explicit Name: label first, then dc:creator ─────────
  // Helper to set name from a string
  const setNameFromStr = (raw) => {
    raw = raw.trim();
    if (!raw || raw.length < 3) return false;
    const cap = w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
    const parts = raw.split(/\s+/).filter(Boolean);
    if (parts.length < 2 || parts.length > 4) return false;
    // Must be purely alphabetic (allow hyphens, apostrophes)
    if (!parts.every(p => /^[A-Za-z][A-Za-z'\-]*$/.test(p))) return false;
    data.personal.firstName = cap(parts[0]);
    data.personal.lastName  = parts.slice(1).map(cap).join(' ');
    return true;
  };

  // Check for explicit Name: or Full Name: label anywhere in text (before XML stripping)
  // This covers both XML and plain text resumes
  const nameLabelM = text.match(/(?:^|\n)[^\n]*?(?:full\s*)?name\s*:\s*([^\n<]{3,50})/im);
  if (nameLabelM && !setNameFromStr(nameLabelM[1])) { /* try dc:creator next */ }

  // Fall back to dc:creator metadata
  if (!data.personal.firstName) {
    const creatorM = text.match(/<dc:creator[^>]*>([^<]+)<\/dc:creator>/i);
    if (creatorM) setNameFromStr(creatorM[1]);
  }

  // ── 2. Strip all XML/HTML tags, decode entities, get clean plain text ────────
  let plain = text
    .replace(/<w:instrText[^>]*>.*?<\/w:instrText>/gis, '')
    .replace(/<w:fldChar[^>]*\/>/gi, '')
    .replace(/<w:tab[^>]*\/>/gi, ' ')                    // <w:tab/> → space
    .replace(/<\/w:p>/gi,  '\n')
    // </w:r> NOT a space — Word splits words across runs
    .replace(/(<br)[^>]*(>)/gi, '\n')
    .replace(/<\/p>/gi,    '\n')
    .replace(/<[^>]+>/g,   '')
    .replace(/&amp;/g,  '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#x27;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  // lines_with_blanks preserves empty lines — needed for cert block splitting
  const lines_with_blanks = plain.split('\n').map(l => l.trim());
  const lines = lines_with_blanks.filter(Boolean);
  const full  = lines.join('\n');

  // ── 3. Contact info — scan entire document for patterns ──────────────────────
  // Email: require local part to start with a letter to avoid grabbing leading phone digits
  const emailM = full.match(/[a-zA-Z][\w.+\-]*@[\w\-]+\.[a-z]{2,}/i);
  if (emailM) data.personal.email = emailM[0];

  const phoneM = full.match(/(\(?\d{3}\)?[\s\-.\u2013]\d{3}[\s\-.\u2013]\d{4})/);
  if (phoneM) data.personal.phone = phoneM[0].replace(/\u2013/g, '-');

  // LinkedIn — check extracted hyperlink URLs first (handles URL-behind-display-text),
  // then fall back to plain-text scan of the document body.
  let liM = null;
  for (const url of hyperlinkURLs) {
    liM = url.match(/(?:www\.)?linkedin\.com\/in\/([\w\-]+)/i);
    if (liM) break;
  }
  if (!liM) liM = full.match(/(?:www\.)?linkedin\.com\/in\/([\w\-]+)/i);
  if (liM) data.personal.linkedin = 'linkedin.com/in/' + liM[1];

  const ghM = full.match(/github\.com\/([\w\-]+)/i);
  if (ghM) data.personal.github = 'github.com/' + ghM[1];

  // ── 4. If name not from metadata, try first lines ────────────────────────────
  if (!data.personal.firstName) {
    for (const line of lines.slice(0, 8)) {
      const lv = extractLabel(line);
      // Skip label lines for name detection
      if (lv && ['email','phone','title','name','contact','from','to'].includes(lv.label)) continue;
      const clean = line.trim();
      if (clean.length < 3 || clean.length > 50) continue;
      if (clean.includes('@') || /\d/.test(clean)) continue;
      if (/[|•:\/\\]/.test(clean)) continue;
      if (/\b(street|ave|blvd|drive|road|experience|education|skills|summary|certif|reference|work|employ)\b/i.test(clean)) continue;
      if (!/^[A-Za-z][A-Za-z'\-\.]+(?:\s+[A-Za-z][A-Za-z'\-\.]*){1,3}$/.test(clean)) continue;
      const words = clean.split(/\s+/);
      if (words.length >= 2 && words.length <= 4) {
        const cap = w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
        data.personal.firstName = cap(words[0]);
        data.personal.lastName  = words.slice(1).map(cap).join(' ');
        break;
      }
    }
  }

  // ── 5. Section splitter — identify major headings ────────────────────────────
  const SECTION_HEADING_RE = /^(work\s*experience|professional\s*experience|experience|employment\s*history|employment|career|education|academic|certif\w*|licens\w*|skills?|technical\s*skills?|key\s*competencie\w*|competencie\w*|core\s*competencie\w*|areas?\s*of\s*expertise|expertise|summary|professional\s*summary|objective|overview|profile|references?|contact\s*information?|contact|volunteer|award\w*|honor\w*|publication\w*|language\w*|interest\w*)/i;

  const sections = { header: [] };
  let curSection = 'header';

  for (const line of lines_with_blanks) {
    const lv = extractLabel(line);
    const headingText = lv ? lv.label : line.toLowerCase().trim();
    // Guard: after matching the section keyword, the remainder must not start with a
    // preposition/article (e.g. "certification in AWS" is a description, not a heading)
    const _headingMatch = SECTION_HEADING_RE.exec(headingText);
    const _isRealHeading = _headingMatch &&
      !/^(in|for|as|with|from|to|at|on|by|the|a|an)\b/i.test(headingText.slice(_headingMatch[0].length).trim());
    if (line.trim() && _isRealHeading && line.length < 65) {
      const key = headingText.replace(/[^a-z0-9 ]/g,'').trim();
      curSection = key;
      if (!sections[curSection]) sections[curSection] = [];
      // If the heading line has a value (e.g. "Education: University of Kansas"),
      // push that value as the first content line of the section
      if (lv && lv.value && lv.value.trim()) {
        sections[curSection].push(lv.label.replace(/\w/g,c=>c.toUpperCase()) + ': ' + lv.value);
      }
    } else {
      if (!sections[curSection]) sections[curSection] = [];
      // Push the line as-is (including blanks) so cert block splitter sees blank lines
      sections[curSection].push(line);
    }
  }

  const findSection = re => {
    const key = Object.keys(sections).find(k => re.test(k));
    return key ? sections[key] : null;
  };

  // ── 6. Parse header section for personal address fields ──────────────────────
  const headerLines = sections['header'] || [];
  for (const line of headerLines) {
    const lv = extractLabel(line);
    if (!lv) continue;
    const { label, value } = lv;
    if (/^(street\s*(address)?\s*(line\s*1)?|address\s*(line\s*1)?|addr1?|home\s*address)$/.test(label)) data.location.street1 = value;
    else if (/^(address\s*line\s*2|apt|suite|unit)$/.test(label)) data.location.street2 = value;
    else if (/^city$/.test(label)) data.location.city = value;
    else if (/^state$/.test(label)) data.location.state = value;
    else if (/^(zip|postal)/.test(label)) data.location.zip = value;
    else if (/^country$/.test(label)) data.location.country = value;
  }
  // Fallback: "City, ST ZIP" on a header line
  if (!data.location.city) {
    for (const line of headerLines) {
      if (!extractLabel(line) && /^[A-Z][a-z]/.test(line)) {
        const loc = parseLocation(line);
        if (loc.city && loc.state) {
          if (!data.location.city)  data.location.city  = loc.city;
          if (!data.location.state) data.location.state = loc.state;
          if (!data.location.zip && loc.zip) data.location.zip = loc.zip;
          break;
        }
      }
    }
  }
  // ZIP anywhere in document
  if (!data.location.zip) {
    const zipM = full.match(/\b(\d{5})(?:[\s\-]\d{4})?\b/);
    if (zipM) data.location.zip = zipM[1];
  }

  // ── 7. Parse EXPERIENCE section ───────────────────────────────────────────────
  // Supports two formats:
  //   A) Labeled  — "Company: ...", "Title: ...", "From: ...", "To: ..."
  //   B) PlainText — "Company, City, ST  MM/YYYY – MM/YYYY" + "Title: Desc" lines
  const expLines = findSection(/experience|employment|positions?|career/);
  if (expLines) {
    const DATE_RANGE_RE = /\b(\d{1,2}\/\d{4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4})\s*[–—\-]\s*(\d{1,2}\/\d{4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4}|present|current|now)\b/i;
    const hasCompanyLabel = expLines.some(l => { const lv = extractLabel(l); return lv && /^company$/.test(lv.label); });
    const isPlainText = !hasCompanyLabel && expLines.some(l => DATE_RANGE_RE.test(l));
    data.experiences = isPlainText ? parsePlainTextExperience(expLines) : parseLabeledExperience(expLines);
  }

  // ── 8. Parse EDUCATION section using Label: cues ─────────────────────────────
  const eduLines = findSection(/education|academic|school/);
  if (eduLines) {
    data.educations = parseLabeledEducation(eduLines);
  }

  // ── 9. Parse CERTIFICATIONS using Label: cues ────────────────────────────────
  const certLines = findSection(/certif|licens/);
  if (certLines) {
    data.certs = parseLabeledCerts(certLines);
  }

  // ── 10. Summary / Overview / Objective ───────────────────────────────────────
  const summaryLines = findSection(/summary|objective|profile|overview/);
  let summaryText = '';
  if (summaryLines?.length) {
    summaryText = summaryLines.filter(Boolean).slice(0, 6).join(' ').trim().substring(0, 600);
  }
  // Also look for top-level "Title:" label as the professional summary
  if (!summaryText) {
    for (const line of lines.slice(0, 5)) {
      const lv = extractLabel(line);
      if (lv && lv.label === 'title' && lv.value.length > 30) {
        summaryText = lv.value;
        break;
      }
    }
  }
  // Fallback: look in the header section for the first long descriptive paragraph
  // (handles resumes where the summary appears before any labelled section heading)
  if (!summaryText) {
    const headerSec = sections['header'] || [];
    for (const line of headerSec) {
      if (
        line.length > 80 &&
        !extractLabel(line) &&
        !/@/.test(line) &&                   // not a contact line
        !/\d{3}[\s.\-]\d{3}/.test(line) &&  // not a phone number line
        !/^\s*[\u2022\u25CF\-\*]/.test(line) // not a bullet
      ) {
        summaryText = line.trim().substring(0, 600);
        break;
      }
    }
  }
  if (summaryText) {
    data.cover.aboutMe = summaryText;
    // Populate the overviews array so it appears on the Overview tab
    data.overviews = [{ text: summaryText, useInFill: true }];
  }

  // ── 11. Skills / Competencies ─────────────────────────────────────────────────
  const skillsLines = findSection(/skill|competenci|expertise/);
  if (skillsLines?.length) {
    // Join all non-blank lines; normalise bullet separators to commas
    const skillText = skillsLines
      .filter(Boolean)
      .join(' ')
      .replace(/\s*[•·]\s*/g, ', ')   // bullet → comma
      .replace(/,\s*,/g, ',')
      .replace(/\s{2,}/g, ' ')
      .trim()
      .substring(0, 600);
    if (skillText) {
      data.skillSets = [{ text: skillText, useInFill: true }];
    }
  }

  // ── Apply + report ────────────────────────────────────────────────────────────
  applyImportData(data);

  const filled = [];
  if (data.personal.firstName)   filled.push('Name');
  if (data.personal.email)       filled.push('Email');
  if (data.personal.phone)       filled.push('Phone');
  if (data.personal.linkedin)    filled.push('LinkedIn');
  if (data.personal.github)      filled.push('GitHub');
  if (data.location.city)        filled.push('City/State');
  if (data.location.street1)     filled.push('Address');
  if (data.location.zip)         filled.push('ZIP');
  if (data.experiences.length)   filled.push(`${data.experiences.length} job${data.experiences.length > 1 ? 's' : ''}`);
  if (data.educations.length)    filled.push(`${data.educations.length} school${data.educations.length > 1 ? 's' : ''}`);
  if (data.certs.length)         filled.push(`${data.certs.length} cert${data.certs.length > 1 ? 's' : ''}`);
  if (data.cover.aboutMe)        filled.push('Summary');

  switchTab('personal');
  showParseOk(
    filled.length
      ? `✓ Filled: ${filled.join(' · ')}`
      : '⚠ Parsed but found little — ensure resume has contact info at the top.',
    filled.length === 0
  );
}

// ── Experience: Label-driven parser ──────────────────────────────────────────
// Recognises: Company:, From:, To:, Title:, Location:, Description:
// A new job starts whenever a "Company:" label is seen.
function parseLabeledExperience(lines) {
  const jobs = [];
  let cur = null;
  let inDesc = false;

  function flush() {
    if (cur && (cur.company || cur.title)) {
      // Split description into sentences for the checkbox UI
      if (cur.description) {
        cur.sentences = splitToSentences(cur.description);
        cur.sentenceChecked = cur.sentences.map(() => true);
      }
      jobs.push(cur);
    }
  }

  for (const line of lines) {
    const lv = extractLabel(line);

    if (lv) {
      const { label, value } = lv;

      if (/^company$/.test(label)) {
        flush();
        cur = { company: value, description: '' };
        inDesc = false;
      } else if (!cur) {
        // Haven't seen a Company: yet — skip
        continue;
      } else if (/^(title|position|role|job\s*title)$/.test(label)) {
        cur.title = value;
        inDesc = false;
      } else if (/^(from|start\s*date|started?)$/.test(label)) {
        const d = parseDateStr(value);
        if (d.month) cur.startMonth = d.month;
        if (d.day)   cur.startDay   = d.day;
        else if (d.month) cur.startDay = 1;  // default day=1 when month known
        if (d.year)  cur.startYear  = d.year;
        inDesc = false;
      } else if (/^(to|end\s*date|ended?)$/.test(label)) {
        if (/present|current|now/i.test(value)) {
          cur.present = true;
        } else {
          const d = parseDateStr(value);
          if (d.month) cur.endMonth = d.month;
          if (d.day)   cur.endDay   = d.day;
          else if (d.month) cur.endDay = 1;  // default day=1 when month known
          if (d.year)  cur.endYear  = d.year;
        }
        inDesc = false;
      } else if (/^location$/.test(label)) {
        const loc = parseLocation(value);
        cur.compCity    = loc.city    || value;
        cur.compState   = loc.state   || '';
        cur.compZip     = loc.zip     || '';
        inDesc = false;
      } else if (/^(description|responsibilities|duties|summary)$/.test(label)) {
        inDesc = true;
        if (value) cur.description = (cur.description ? cur.description + '\n' : '') + value;
      } else if (/^(client|clients?)$/.test(label)) {
        // "Client: CompanyName" — prepend to description
        cur.description = (`Client: ${value}` + (cur.description ? '\n' + cur.description : '')).trim();
      } else if (inDesc) {
        cur.description = ((cur.description || '') + '\n' + line).trim();
      }
    } else if (cur && inDesc && line.length > 1) {
      // Continuation of description (bullet points etc.)
      cur.description = ((cur.description || '') + '\n' + line.replace(/^[\u2022\u25CF\u25AA\-\*\+>]\s*/, '')).trim();
    } else if (cur && !inDesc && line.length > 1 && !/^[\u2022\u25CF\u25AA\-\*\+>]/.test(line)) {
      // Non-labeled, non-bullet line that isn't description — might be continuation of title
      if (!cur.title && line.length < 80) cur.title = line;
    }
  }
  flush();
  return jobs.filter(j => j.company || j.title);
}

// ── Plain-text experience parser ─────────────────────────────────────────────
// Handles resumes where each job block starts with:
//   "Company Name, City, ST   MM/YYYY – MM/YYYY"   (date range on the company line)
//   "Job Title: Optional description text"          (title line immediately after)
//   Bullet / paragraph lines                        (description content)
function parsePlainTextExperience(lines) {
  const DATE_RANGE_RE = /\b(\d{1,2}\/\d{4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4})\s*[–—\-]\s*(\d{1,2}\/\d{4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4}|present|current|now)\b/i;
  const jobs = [];
  let cur = null;

  function flush() {
    if (cur && (cur.company || cur.title)) {
      if (cur.description) {
        cur.sentences = splitToSentences(cur.description);
        cur.sentenceChecked = cur.sentences.map(() => true);
      }
      jobs.push(cur);
    }
  }

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const dateMatch = DATE_RANGE_RE.exec(trimmed);
    if (dateMatch) {
      // ── New job block ────────────────────────────────────────────────────────
      flush();
      // Strip the date range and surrounding whitespace/tabs to get company+location
      const rawCompany = trimmed.slice(0, dateMatch.index).replace(/[\t\s]+$/, '').replace(/,?\s*$/, '').trim();

      // Split "Company Name, City, ST" — state abbreviation is usually the last token
      let company = rawCompany, compCity = '', compState = '';
      const stateM = rawCompany.match(/^(.+?),\s*([^,]+?),\s*([A-Z]{2}(?:\/[A-Z]{2})?)?\s*$/);
      if (stateM) {
        company   = stateM[1].trim();
        compCity  = stateM[2].trim();
        compState = stateM[3] || '';
      } else {
        const ci = rawCompany.indexOf(',');
        if (ci > 0) {
          company = rawCompany.substring(0, ci).trim();
          const rest = rawCompany.substring(ci + 1).trim();
          const loc = parseLocation(rest);
          compCity  = loc.city  || rest;
          compState = loc.state || '';
        }
      }

      const startD = parseDateStr(dateMatch[1]);
      const endD   = parseDateStr(dateMatch[2]);
      cur = { company, compCity, compState, description: '' };
      if (startD.month) cur.startMonth = startD.month;
      if (startD.year)  cur.startYear  = startD.year;
      if (/present|current|now/i.test(dateMatch[2])) {
        cur.present = true;
      } else {
        if (endD.month) cur.endMonth = endD.month;
        if (endD.year)  cur.endYear  = endD.year;
      }
    } else if (cur && !cur.title) {
      // ── Title line (first content line after company) ─────────────────────────
      if (/^key\s*competenci/i.test(trimmed)) continue; // skip sub-headers
      const lv = extractLabel(trimmed);
      if (lv && lv.label.length <= 60 && lv.label.split(/\s+/).length <= 8) {
        // Standard case: "Job Title: description" — extractLabel worked
        cur.title = lv.label.replace(/\b\w/g, c => c.toUpperCase()).trim();
        if (lv.value.trim()) cur.description = lv.value.trim();
      } else {
        // extractLabel fails when title contains "." (e.g. "Sr. Manager") or other
        // chars outside its class. Fall back to a raw colon-split on the line.
        const ci = trimmed.indexOf(':');
        if (ci > 0 && ci <= 60) {
          // "Sr. Project Manager: (Client: Acme) Description..."
          cur.title = trimmed.substring(0, ci).trim();
          const rest = trimmed.substring(ci + 1).trim();
          if (rest) cur.description = rest;
        } else if (trimmed.length < 100) {
          cur.title = trimmed;
        } else {
          // Long line with no early colon — use as description content
          cur.description = trimmed.replace(/^[\u2022\u25CF\u25AA\-\*\+>]\s*/, '').trim();
        }
      }
    } else if (cur) {
      // ── Description / bullet lines ────────────────────────────────────────────
      if (/^key\s*competenci/i.test(trimmed)) continue;          // skip "Key Competencies: …"
      const lv = extractLabel(trimmed);
      if (lv && /^key\s*competenci/i.test(lv.label)) continue;   // labeled variant
      const clean = trimmed.replace(/^[\u2022\u25CF\u25AA\-\*\+>]\s*/, '').trim();
      if (clean.length > 1) {
        cur.description = ((cur.description || '') + ' ' + clean).trim();
      }
    }
  }
  flush();
  return jobs.filter(j => j.company || j.title);
}

// ── Education: Label-driven parser ───────────────────────────────────────────
// Recognises: University:, School:, Degree:, Field of study:, Date:, GPA:, Location:
function parseLabeledEducation(lines) {
  const schools = [];
  let cur = null;

  function flush() {
    if (cur && (cur.school || cur.degree)) schools.push(cur);
  }

  // Degree keyword used to detect "School Name, Location: Degree – Field" format
  const DEGREE_WORD_RE = /\b(bachelor|master|mba|phd|doctor|associate|diploma|certificate|b\.s|b\.a|m\.s|m\.a|b\.sc|m\.sc|a\.s|a\.a)\b/i;

  for (const line of lines) {
    const lv = extractLabel(line);
    if (!lv) {
      // ── Unlabeled line ─────────────────────────────────────────────────────────
      // Special case: "School Name, City, ST: Degree – Field" where extractLabel
      // returns null because the school name contains commas (before the colon).
      // Detect by scanning for the FIRST colon anywhere in the line.
      const colonIdx = line.indexOf(':');
      if (colonIdx > 0 && colonIdx < line.length - 1) {
        const possibleSchool  = line.substring(0, colonIdx).trim();
        const possibleDegree  = line.substring(colonIdx + 1).trim();
        if (DEGREE_WORD_RE.test(possibleDegree) && possibleSchool.length > 3) {
          if (cur && (cur.school || cur.degree)) flush();
          cur = {};
          // School name is before the first comma (city/state follows)
          const ci = possibleSchool.indexOf(',');
          cur.school = ci > 0 ? possibleSchool.substring(0, ci).trim() : possibleSchool.trim();
          // Degree may include " – Field" and/or "– Honors/misc" suffix
          const dashParts = possibleDegree.split(/\s*[–—]\s*/);
          cur.degree = dashParts[0]
            .replace(/,\s*(cum\s+laude|magna\s+cum\s+laude|summa\s+cum\s+laude|with\s+honors?)\s*$/i, '')
            .trim();
          if (dashParts[1]) {
            // Second segment is the field of study
            cur.field = dashParts[1].replace(/\s*[–—].*$/, '').trim();
          }
          // Third segment and beyond (e.g. "Summa Cum Laude") → miscData
          if (dashParts[2]) {
            cur.miscData = dashParts.slice(2).join(' – ').trim();
          }
          // Also capture honors appended to the degree/field via comma (e.g. ", Summa Cum Laude")
          const honorsM = possibleDegree.match(/,\s*((?:summa|magna)\s+cum\s+laude|cum\s+laude|with\s+honors?)\s*$/i);
          if (honorsM && !cur.miscData) cur.miscData = honorsM[1].trim();
          const yearM = possibleDegree.match(/\b(19|20)\d{2}\b/);
          if (yearM) cur.gradYear = yearM[0];
          continue;
        }
      }
      // Normal unlabeled line — treat as school name if no school recorded yet
      if (cur && !cur.school && line.length > 2 && !/^\d/.test(line)) cur.school = line;
      else if (!cur && line.length > 2) { cur = {}; cur.school = line; }
      continue;
    }

    const { label, value } = lv;

    if (/^(university|college|school|institution)$/.test(label)) {
      // "University: Name of University" — school name IS the value
      if (cur && (cur.school || cur.degree)) flush();
      cur = {};
      cur.school = value;
    } else if (/^(school|liberal arts|department|faculty|division)$/.test(label)) {
      if (!cur) cur = {};
      // "School: Liberal Arts and Sciences" = field/division
      if (!cur.field) cur.field = value;
    } else if (/^(degree|qualification|diploma)$/.test(label)) {
      if (!cur) cur = {};
      cur.degree = value;
    } else if (/^(field\s*of\s*study|major|concentration|subject|program)$/.test(label)) {
      if (!cur) cur = {};
      cur.field = value;
    } else if (/^(date|graduation\s*date?|grad\s*date?|graduated?)$/.test(label)) {
      if (!cur) cur = {};
      const d = parseDateStr(value);
      if (d.year) { cur.gradYear = d.year; cur.finished = true; }
    } else if (/^(gpa|grade\s*point)$/.test(label)) {
      if (!cur) cur = {};
      cur.gpa = value.match(/\d\.\d{1,2}/)?.[0] || value;
    } else if (/^location$/.test(label)) {
      // Ignore location for education (it's the school's location, not needed in form)
    } else if (/^(start|from)$/.test(label)) {
      if (!cur) cur = {};
      const d = parseDateStr(value);
      if (d.year) cur.startYear = d.year;
    }
  }
  flush();
  return schools.filter(s => s.school || s.degree);
}

// ── Certifications parser v2 ─────────────────────────────────────────────────
// Supports two modes:
//
// MODE A — Blank-line separated blocks (recommended format):
//   "Certification Name: Project Management Professional"
//   "Authority: Project Management Institute"
//   "Certificate Number: 1606509"
//   "Issued Date: 05/14/2013"
//   "Status: Current"
//   <blank line>
//   "Certification Name: Agile Scrum Master"
//   <blank line>
//
// MODE B — George's current format (no blank lines, positional):
//   "Project Management Institute"     <- authority
//   "Project Management Professional"  <- cert name
//   "Certificate number: 1606509"
//   "Issued Date: 05/14/2013"
//   "Status: Current"
//   "George Washington University"     <- starts new cert block (new authority)
//   ...
//   "SaFE Agilist version 4.0"         <- standalone (no following name before next authority)
//
// Detection: if ANY line in the section matches "Certification Name:" or "Certification:"
// with a value, use MODE A. Otherwise use MODE B (positional).

function parseLabeledCerts(lines) {
  // Detect which mode:
  // Mode A (George's new format): "Certification Name:" label present with a value
  // Mode B (legacy positional): no such label
  const hasCertLabel = lines.some(l => {
    const lv = extractLabel(l);
    return lv && /^(certification\s*name|certification)$/.test(lv.label) && lv.value.length > 0;
  });
  return hasCertLabel ? parseCertsModeA(lines) : parseCertsModeB(lines);
}

// MODE A — blank-line-separated blocks, each block introduced by "Certification Name:"
//
// George's exact format per block:
//   Line 1: "Certification Name: <authority-or-certname>"
//   Line 2: (optional) unlabeled cert name  (if present, line 1 value = authority)
//   Rest:   labeled fields (Authority:, Certificate number:, Issued Date:, Status:, etc.)
//
// Rule: if the line immediately after "Certification Name:" (within the same blank-line block)
// is an unlabeled line, then "Certification Name:" value = authority, unlabeled = cert name.
// If no unlabeled line follows before the next labeled/blank, then value = cert name.
function parseCertsModeA(lines) {
  const result = [];

  // Split into blank-line-separated blocks first
  const blocks = [];
  let cur = [];
  for (const line of lines) {
    if (line.trim() === '') {
      if (cur.length) { blocks.push(cur); cur = []; }
    } else {
      cur.push(line.trim());
    }
  }
  if (cur.length) blocks.push(cur);

  for (const block of blocks) {
    const cert = {};

    for (let idx = 0; idx < block.length; idx++) {
      const line = block[idx];
      const lv = extractLabel(line);

      if (!lv) {
        // Unlabeled line — this is the cert name (authority was set by Certification Name:)
        if (!cert.name) cert.name = line;
        continue;
      }

      const { label, value } = lv;

      if (/^(certification\s*name|certification)$/.test(label)) {
        // Look ahead: is the next line in this block unlabeled?
        const nextLine = block[idx + 1];
        const nextLv = nextLine ? extractLabel(nextLine) : null;
        if (nextLine && !nextLv) {
          // Next is unlabeled → current value is the authority, next is cert name
          cert.authority = value;
          cert.name = nextLine.trim();
          idx++; // consume the next line
        } else {
          // No unlabeled follows → value is the cert name itself
          cert.name = value;
        }
      } else if (/^(authority|issuer|issued?\s*by|provider|organization|institution)$/.test(label)) {
        cert.authority = value;
      } else if (/^(cert\s*(number|#|no\.?|num\w*)?|credential\s*id|certificate\s*number|number)$/.test(label)) {
        cert.certNum = value;
      } else if (/^(issued?\s*date?|completed?|earned?|date)$/.test(label)) {
        const d = parseDateStr(value);
        if (d.month) cert.completedMonth = d.month;
        if (d.year)  cert.completedYear  = d.year;
      } else if (/^(expir\w*|valid\s*(until|thru|through)?)$/.test(label)) {
        const d = parseDateStr(value);
        if (d.month) cert.expiresMonth = d.month;
        if (d.year)  cert.expiresYear  = d.year;
      } else if (/^status$/.test(label)) {
        cert.current = !/expir|no|false/i.test(value);
      }
    }

    if (cert.name || cert.authority) result.push(cert);
  }

  return result;
}

// MODE B — legacy positional (no Certification Name: labels)
// Each cert block ends when a new unlabeled line appears after labeled fields have been seen,
// or when a 3rd consecutive unlabeled line appears.
function parseCertsModeB(lines) {
  const result = [];
  let cur = null;
  let hadLabels = false;
  let unlabeled = 0;

  function flush() { if (cur && (cur.name || cur.authority)) result.push(cur); }

  function isKnownCertLabel(label) {
    return /^(certificate\s*number|cert\s*(#|no\.?|num\w*)?|credential\s*id|number|issued?\s*date?|completed?|earned?|date|expir\w*|status|authority|issuer|issued?\s*by)$/.test(label);
  }

  function applyKnownLabel(obj, label, value) {
    if (/^(cert\s*(number|#|no\.?|num\w*)?|credential\s*id|certificate\s*number|number)$/.test(label)) obj.certNum = value;
    else if (/^(issued?\s*date?|completed?|earned?|date)$/.test(label)) {
      const d = parseDateStr(value); if (d.month) obj.completedMonth=d.month; if (d.year) obj.completedYear=d.year;
    } else if (/^(expir\w*|valid\s*(until|thru|through)?)$/.test(label)) {
      const d = parseDateStr(value); if (d.month) obj.expiresMonth=d.month; if (d.year) obj.expiresYear=d.year;
    } else if (/^status$/.test(label)) { obj.current = !/expir|no|false/i.test(value); }
    else if (/^(authority|issuer|issued?\s*by)$/.test(label)) obj.authority = value;
  }

  for (const line of lines) {
    const clean = line.replace(/^[•●▪\-\*\+>]\s*/, '').trim();
    if (!clean) continue;
    const lv = extractLabel(clean);

    if (lv && isKnownCertLabel(lv.label)) {
      if (!cur) cur = {};
      applyKnownLabel(cur, lv.label, lv.value);
      hadLabels = true; unlabeled = 0;
    } else if (!lv) {
      if (!cur) {
        cur = { _auth: clean }; unlabeled = 1; hadLabels = false;
      } else if (cur._auth && unlabeled === 1 && !hadLabels) {
        cur.authority = cur._auth; delete cur._auth;
        cur.name = clean; unlabeled = 2;
      } else {
        if (cur._auth) { cur.name = cur._auth; delete cur._auth; }
        flush();
        cur = { _auth: clean }; unlabeled = 1; hadLabels = false;
      }
    }
  }
  if (cur) { if (cur._auth) { cur.name = cur._auth; delete cur._auth; } flush(); }
  return result.filter(c => c.name || c.authority);
}

// ── Tab switcher ──────────────────────────────────────────────────────────────
function switchTab(tabName) {
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === tabName);
  });
  document.querySelectorAll('.panel').forEach(p => {
    p.classList.toggle('active', p.id === 'panel-' + tabName);
  });
}


function showParseOk(msg, isErr=false) {
  const el = $('parseResult');
  el.style.display = 'block';
  el.textContent   = msg;
  el.style.background = isErr ? 'var(--red-lt)'          : 'var(--green-lt)';
  el.style.border     = isErr ? '2px solid var(--red)'   : '2px solid var(--green)';
  el.style.color      = isErr ? 'var(--red)'             : 'var(--green-dk)';
}

// ── CSV EXPORT ────────────────────────────────────────────────────────────────
$('exportCsvBtn').onclick = () => {
  const d = collectAll();
  const rows = [['key','value']];

  // Helper: serialize a value — booleans always 'true'/'false', undefined/null → ''
  const ser = (v, defaultBool) => {
    if (v === undefined || v === null) return defaultBool !== undefined ? String(defaultBool) : '';
    if (typeof v === 'boolean') return String(v);
    return String(v);
  };
  // useInFill defaults to true when not explicitly set
  const serUse = v => ser(v === undefined ? true : v);
  // other booleans default to false when not set
  const serBool = v => ser(v === undefined ? false : v);

  PERSONAL_IDS.forEach(k => rows.push(['personal.'+k, d.personal[k]||'']));
  PERSONAL_CK_IDS.forEach(k => rows.push(['personal.'+k, d.personal[k] !== false ? 'true' : 'false']));
  LOCATION_IDS.forEach(k => rows.push(['location.'+k, d.location[k]||'']));
  COVER_IDS.forEach(k    => rows.push(['cover.'+k,    d.cover[k]||'']));
  // Overviews — 3 entries, each with text + useInFill
  (d.overviews || overviews).forEach((ov, i) => {
    rows.push([`overview${i}.text`,      ov.text      || '']);
    rows.push([`overview${i}.useInFill`, ov.useInFill !== false ? 'true' : 'false']);
  });
  // SkillSets — 3 entries, each with text + useInFill
  (d.skillSets || skillSets).forEach((sk, i) => {
    rows.push([`skillSet${i}.text`,      sk.text      || '']);
    rows.push([`skillSet${i}.useInFill`, sk.useInFill !== false ? 'true' : 'false']);
  });

  // Experience scalar fields (no description — sentences handled separately)
  const expScalar = ['company','companyPhone','compStreet1','compStreet2','compCity','compState','compZip','compCountry',
    'title','altTitle1','altTitle2','activeTitleIdx','empType',
    'startMonth','startDay','startYear','endMonth','endDay','endYear'];
  d.experiences.forEach((exp,i) => {
    expScalar.forEach(k => rows.push([`exp${i}.${k}`, exp[k]!==undefined?exp[k]:'']));
    rows.push([`exp${i}.present`,   serBool(exp.present)]);
    rows.push([`exp${i}.useInFill`, serUse(exp.useInFill)]);
    // Each sentence is its own row, with its checked state
    const sents = exp.sentences || (exp.description ? [exp.description] : []);
    const checks = exp.sentenceChecked || sents.map(() => true);
    sents.forEach((s, si) => {
      rows.push([`exp${i}.sent${si}`, s]);
      rows.push([`exp${i}.sentCk${si}`, checks[si] !== false ? 'true' : 'false']);
    });
  });

  const eduScalar = ['school','degree','field','startYear','gradYear','gpa','miscData'];
  d.educations.forEach((edu,i) => {
    eduScalar.forEach(k => rows.push([`edu${i}.${k}`, edu[k]!==undefined?edu[k]:'']));
    rows.push([`edu${i}.finished`, serBool(edu.finished)]);
  });

  const certScalar = ['name','certType','authority','certNum','completedMonth','completedYear','expiresMonth','expiresYear'];
  d.certs.forEach((c,i) => {
    certScalar.forEach(k => rows.push([`cert${i}.${k}`, c[k]!==undefined?c[k]:'']));
    rows.push([`cert${i}.current`,   serBool(c.current)]);
    rows.push([`cert${i}.useInFill`, serUse(c.useInFill)]);
  });

  d.refs.forEach((r,i) => {
    ['name','title','company','phone','email'].forEach(k => rows.push([`ref${i}.${k}`, r[k]||'']));
    rows.push([`ref${i}.useInFill`, serUse(r.useInFill)]);
  });

  const csv = rows.map(([k,v]) => `"${k}","${String(v).replace(/"/g,'""')}"`).join('\n');
  const url = URL.createObjectURL(new Blob([csv], {type:'text/csv'}));
  Object.assign(document.createElement('a'), {href:url, download:'jobfill-profile.csv'}).click();
  URL.revokeObjectURL(url);
  showToast('⬇ CSV exported!','g');
};

// ── CSV IMPORT ────────────────────────────────────────────────────────────────
$('importCsvBtn').onclick = () => $('csvFileInput').click();
$('csvFileInput').onchange = e => {
  const file = e.target.files[0];
  if (!file) return;
  readAsText(file, text => {
    try {
      const map = {};
      text.split('\n').slice(1).forEach(line => {
        const m = line.match(/^"([^"]+)","((?:[^"]|"")*)"/);
        if (m) map[m[1]] = m[2].replace(/""/g,'"').replace(/\r/g,'');
      });
      if (_storageLoaded) {
        applyImportData(buildFromMap(map), { overwrite: true });
      } else {
        _pendingImport = map;
      }
      showToast('⬆ CSV imported!','g');
    } catch(err) { showToast('⚠ Import failed: '+err.message,'r'); }
  });
  // Reset so selecting the same file again still fires onchange
  e.target.value = '';
};

// Guard against prototype pollution from untrusted CSV keys
const PROTO_DENY = new Set(['__proto__','constructor','prototype']);
function safeProp(obj, subkey, val) {
  if (PROTO_DENY.has(subkey)) return; // block dangerous keys
  obj[subkey] = val;
}

function buildFromMap(map) {
  const d = { personal:{}, location:{}, cover:{}, overviews:[], skillSets:[], experiences:[], educations:[], certs:[], refs:[] };
  Object.entries(map).forEach(([key,val]) => {
    const boolVal = val==='true' ? true : val==='false' ? false : val;
    if (key.startsWith('personal.')) safeProp(d.personal, key.slice(9), val);
    else if (key.startsWith('location.')) safeProp(d.location, key.slice(9), val);
    else if (key.startsWith('cover.'))    safeProp(d.cover,    key.slice(6), val);
    else if (key.startsWith('overview.')) { /* legacy — skip */ }
    else {
      const mOv = key.match(/^overview(\d+)\.(text|useInFill)$/);
      const mSk = key.match(/^skillSet(\d+)\.(text|useInFill)$/);
      if (mOv) {
        const i = +mOv[1];
        if (!d.overviews[i]) d.overviews[i] = { text:'', useInFill: i===0 };
        d.overviews[i][mOv[2]] = mOv[2]==='useInFill' ? (val==='true') : val;
      }
      if (mSk) {
        const i = +mSk[1];
        if (!d.skillSets[i]) d.skillSets[i] = { text:'', useInFill: i===0 };
        d.skillSets[i][mSk[2]] = mSk[2]==='useInFill' ? (val==='true') : val;
      }
      const mExp  = key.match(/^exp(\d+)\.(.+)/);
      const mEdu  = key.match(/^edu(\d+)\.(.+)/);
      const mCert = key.match(/^cert(\d+)\.(.+)/);
      const mRef  = key.match(/^ref(\d+)\.(.+)/);
      if (mExp)  {
        const i=+mExp[1];
        if(!d.experiences[i]) d.experiences[i]={sentences:[],sentenceChecked:[]};
        const expObj = d.experiences[i];
        const field = mExp[2];
        // Handle sent0, sent1... and sentCk0, sentCk1...
        const sentM = field.match(/^sent(\d+)$/);
        const sentCkM = field.match(/^sentCk(\d+)$/);
        if (sentM) {
          expObj.sentences[+sentM[1]] = val;
        } else if (sentCkM) {
          if (!expObj.sentenceChecked) expObj.sentenceChecked = [];
          expObj.sentenceChecked[+sentCkM[1]] = (val !== 'false');
        } else {
          expObj[field] = boolVal;
        }
      }
      if (mEdu)  { const i=+mEdu[1];  if(!d.educations[i])  d.educations[i]={};  d.educations[i][mEdu[2]]=boolVal; }
      if (mCert) { const i=+mCert[1]; if(!d.certs[i])       d.certs[i]={};       d.certs[i][mCert[2]]=boolVal; }
      if (mRef)  { const i=+mRef[1];  if(!d.refs[i])        d.refs[i]={};        d.refs[i][mRef[2]]=boolVal; }
    }
  });
  d.experiences=d.experiences.filter(Boolean);
  d.educations =d.educations.filter(Boolean);
  d.certs      =d.certs.filter(Boolean);
  return d;
}

function applyImportData(data, { overwrite = false } = {}) {
  if (overwrite) {
    // ── Full overwrite (CSV import) — clear everything first, then set ──────────
    // Clear all flat fields (set to empty string)
    PERSONAL_IDS.forEach(id => { if($(id)) $(id).value = ''; });
    PERSONAL_CK_IDS.forEach(id => { if($(id)) $(id).checked = true; }); // reset checkboxes to checked
    LOCATION_IDS.forEach(id => { if($(id)) $(id).value = ''; });
    COVER_IDS.forEach(id => { if($(id)) $(id).value = ''; });
    // overviews/skillSets replaced below via array assignment
    // Replace arrays entirely (even if empty — that clears existing data)
    experiences = data.experiences || [];
    educations  = data.educations  || [];
    certs       = data.certs       || [];
    window._refs = (data.refs && data.refs.length) ? data.refs : [{}];
    // Now set flat fields from incoming data (including blanks — user exported them blank)
    if (data.personal) {
      PERSONAL_IDS.forEach(id => { if($(id)) $(id).value = data.personal[id] || ''; });
      PERSONAL_CK_IDS.forEach(id => { if($(id)) $(id).checked = data.personal[id] !== false; });
    }
    if (data.location) LOCATION_IDS.forEach(id => { if($(id)) $(id).value = data.location[id] || ''; });
    if (data.cover)    COVER_IDS.forEach(id => { if($(id)) $(id).value = data.cover[id] || ''; });
    if (data.overviews?.length) { overviews = padArr(data.overviews,  {text:'',useInFill:false}); } renderOverviews();
    if (data.skillSets?.length) { skillSets = padArr(data.skillSets, {text:'',useInFill:false}); } renderSkills();
    renderExperiences();
    renderEducations();
    renderCerts();
    renderRefs();
  } else {
    // ── Merge (resume upload) — only set non-empty values, never blank out ───────
    const setIfVal = (id, val) => { if($(id) && val !== undefined && val !== null && String(val).trim() !== '') $(id).value = String(val); };
    if (data.personal) {
      PERSONAL_IDS.forEach(id => setIfVal(id, data.personal[id]));
      PERSONAL_CK_IDS.forEach(id => { if($(id) && data.personal[id] !== undefined) $(id).checked = data.personal[id] !== false; });
    }
    if (data.location) LOCATION_IDS.forEach(id => setIfVal(id, data.location[id]));
    if (data.cover)    COVER_IDS.forEach(id => setIfVal(id, data.cover[id]));
    if (data.overviews?.length) { overviews = padArr(data.overviews,  {text:'',useInFill:false}); renderOverviews(); }
    if (data.skillSets?.length) { skillSets = padArr(data.skillSets, {text:'',useInFill:false}); renderSkills(); }
    if (data.experiences?.length) { experiences=data.experiences; renderExperiences(); }
    if (data.educations?.length)  { educations=data.educations;   renderEducations(); }
    if (data.certs?.length)       { certs=data.certs;             renderCerts(); }
    if (data.refs?.length)        { window._refs=data.refs;       renderRefs(); }
  }
  saveAll();
}

// ── CLEAR ALL ────────────────────────────────────────────────────────────────
function clearAll() {
  // Clear flat fields
  PERSONAL_IDS.forEach(id => { if($(id)) $(id).value = ''; });
  PERSONAL_CK_IDS.forEach(id => { if($(id)) $(id).checked = true; }); // reset to checked (default)
  LOCATION_IDS.forEach(id => { if($(id)) $(id).value = ''; });
  COVER_IDS.forEach(id    => { if($(id)) $(id).value = ''; });
  // Reset arrays
  experiences = [];
  educations  = [];
  certs       = [];
  window._refs = [{},{},{}];
  overviews  = [{text:'',useInFill:true},{text:'',useInFill:false},{text:'',useInFill:false}];
  skillSets  = [{text:'',useInFill:true},{text:'',useInFill:false},{text:'',useInFill:false}];
  // Re-render dynamic sections
  renderExperiences();
  renderEducations();
  renderCerts();
  renderRefs();
  renderOverviews();
  renderSkills();
  // Wipe storage
  chrome.storage.local.clear(() => showToast('✓ All data cleared','g'));
}

$('clearBtn').onclick = () => {
  if (confirm('Clear all saved information? This cannot be undone.')) clearAll();
};

// ── TOAST ─────────────────────────────────────────────────────────────────────
function showToast(msg, cls='') {
  const t=$('toast');
  t.textContent=msg;
  t.className='toast'+(cls?' '+cls:'');
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove('show'), 2600);
}

// ── CRAFT RESUME — resume built from stored profile data ────────────────────────

// ── Zone helper ───────────────────────────────────────────────────────────────
function wireZone(zoneId, inputId, titleId, subId, onFile) {
  const zone  = $(zoneId);
  const input = $(inputId);
  if (!zone || !input) return;
  zone.onclick = () => input.click();
  zone.addEventListener('dragover',  e => { e.preventDefault(); zone.style.opacity = '.8'; });
  zone.addEventListener('dragleave', () => { zone.style.opacity = ''; });
  zone.addEventListener('drop', e => {
    e.preventDefault(); zone.style.opacity = '';
    const f = e.dataTransfer.files[0];
    if (f) onFile(f, zone, titleId, subId);
  });
  input.onchange = e => {
    const f = e.target.files[0];
    if (f) onFile(f, zone, titleId, subId);
    e.target.value = '';
  };
}

function setZoneFile(file, zone, titleId, subId) {
  zone.style.borderStyle = 'solid';
  zone.style.borderColor = 'var(--green)';
  zone.style.background  = 'var(--green-lt)';
  if ($(titleId)) $(titleId).textContent = '✓ ' + file.name;
  if ($(subId))   $(subId).textContent   = 'Click or drop to replace';
}

wireZone('sampleZone',   'sampleFileInput',   'sampleZoneTitle',   'sampleZoneSub', (f, z, t, s) => {
  _sampleFile = f;
  setZoneFile(f, z, t, s);
});
wireZone('templateZone', 'templateFileInput', 'templateZoneTitle', 'templateZoneSub', (f, z, t, s) => {
  const r = new FileReader();
  r.onload = evt => {
    const text = new TextDecoder('utf-8',{fatal:false}).decode(new Uint8Array(evt.target.result).slice(0,50000));
    if (/<w:cols[^>]*w:num="[2-9]/.test(text)) {
      showToast('⚠ Dual-column templates are not supported', 'r');
      return;
    }
    _templateFile = f;
    setZoneFile(f, z, t, s);
  };
  r.readAsArrayBuffer(f);
});

// ── Theme picker ─────────────────────────────────────────────────────────────────
let _selectedTheme = 'gunsmoke1';
let _themeChosen   = false;   // true once user explicitly picks a theme

const _THEME_LABELS = {
  gunsmoke1:  '⭐ Gunsmoke1',
  aquaman:    '🌊 Aquaman',
  cleanslate: '🗒 Clean Slate',
  blues:      '🎵 The Blues',
};

function _updateThemeIndicator() {
  const ind = $('themeIndicator');
  const nm  = $('themeIndicatorName');
  if (!ind || !nm) return;
  nm.textContent  = _THEME_LABELS[_selectedTheme] || _selectedTheme;
  ind.style.display = 'flex';
}

// ── Theme picker — wired via addEventListener (MV3 CSP: no inline onclick) ─────
function _pickTheme(card) {
  document.querySelectorAll('.theme-card').forEach(c => c.classList.remove('picked'));
  card.classList.add('picked');
  _selectedTheme = card.dataset.theme;
  _themeChosen   = true;
  $('themeModal').classList.remove('show');
  _updateThemeIndicator();
}

function _closeThemeModal() {
  $('themeModal').classList.remove('show');
}

function _openThemePicker() {
  $('themeModal').classList.add('show');
}

// Wire theme cards and cancel button using addEventListener
document.addEventListener('DOMContentLoaded', () => {
  ['gunsmoke1','aquaman','cleanslate','blues'].forEach(id => {
    const card = $('themeCard-' + id);
    if (card) card.addEventListener('click', () => _pickTheme(card));
  });
  const cancelBtn = $('themeModalCancel');
  if (cancelBtn) cancelBtn.addEventListener('click', _closeThemeModal);
  const changeLink = $('themeChangeLink');
  if (changeLink) changeLink.addEventListener('click', e => { e.preventDefault(); _openThemePicker(); });
});


// ── Craft Resume button ───────────────────────────────────────────────────────
$('craftBtn').onclick = () => {
  // Build payload from current stored data
  const data = collectAll();
  const payload = {
    personal:   data.personal,
    location:   data.location,
    cover:      data.cover,
    overview:   (data.overviews  || []).find(o => o.useInFill !== false),
    skills:     (data.skillSets  || []).find(s => s.useInFill !== false),
    experiences: (data.experiences || [])
      .filter(e => e.useInFill !== false)
      .map(e => ({
        ...e,
        // Coerce activeTitleIdx to number — it may arrive as a string after CSV import
        activeTitle: +e.activeTitleIdx === 1 ? (e.altTitle1 || e.title)
                   : +e.activeTitleIdx === 2 ? (e.altTitle2 || e.title)
                   : (e.title || ''),
        description: (() => {
          if (e.sentences && e.sentences.length) {
            const active = e.sentences
              .filter((s, idx) => !e.sentenceChecked || e.sentenceChecked[idx] !== false)
              .join(' ').trim();
            return active || e.description || '';
          }
          return e.description || '';
        })()
      })),
    educations: data.educations || [],
    certs:      (data.certs || []).filter(c => c.useInFill !== false),
    refs:       (data.refs  || []).filter(r => r.useInFill !== false),
  };

  if (!_themeChosen) {
    // Show theme picker — after selection it closes automatically;
    // user clicks Craft Resume again to generate.
    $('themeModal').classList.add('show');
  } else {
    executeCraft(payload);
  }
};

async function executeCraft(payload) {
  const status = $('craftStatus');
  const btn    = $('craftBtn');

  btn.disabled = true;
  btn.textContent = '⏳ Crafting…';
  status.style.display = 'block';
  status.textContent   = 'Preparing your resume…';

  try {
    status.textContent = 'Applying ' + _selectedTheme + ' theme…';

    chrome.runtime.sendMessage({
      action:     'CRAFT_RESUME',
      payload,
      fileB64:    null,
      fileName:   '',
      isTemplate: false,
      theme:      _selectedTheme,
    }, resp => {
      if (chrome.runtime.lastError || !resp || !resp.success) {
        const err = chrome.runtime.lastError?.message || resp?.error || 'Unknown error';
        status.textContent = '⚠ Error: ' + err;
        showToast('⚠ Resume generation failed', 'r');
      } else {
        status.textContent = '✓ Resume ready — check your downloads!';
        showToast('✅ Resume crafted!', 'g');
      }
      btn.disabled = false;
      btn.textContent = '📝 Craft Resume';
    });
  } catch(err) {
    status.textContent = '⚠ ' + err.message;
    btn.disabled = false;
    btn.textContent = '📝 Craft Resume';
  }
}

// ── SUPPORT TAB ───────────────────────────────────────────────────────────────
const APP_VERSION = '1.0.42';

// Set version in the support + about tabs
(function initSupportTab() {
  const vEl = $('supportVersion');
  if (vEl) vEl.textContent = APP_VERSION;
  const avEl = $('aboutVersion');
  if (avEl) avEl.textContent = APP_VERSION;

  // Register button → mailto
  const regBtn = $('registerBtn');
  if (regBtn) {
    regBtn.onclick = () => {
      const subject = encodeURIComponent('JobFill registration - Version ' + APP_VERSION);
      const body = encodeURIComponent(
        'Hello George,\n\nI\'m registering my copy of JobFill. Please keep me in mind for updates.'
      );
      window.open('mailto:selleckg@yahoo.com?subject=' + subject + '&body=' + body);
    };
  }

  // Get Updates button → modal
  const updBtn = $('getUpdatesBtn');
  const modal  = $('updatesModal');
  const closeBtn = $('closeUpdatesModal');
  if (updBtn && modal) {
    updBtn.onclick = () => { modal.style.display = 'flex'; };
  }
  if (closeBtn && modal) {
    closeBtn.onclick = () => { modal.style.display = 'none'; };
  }
  // Close modal on backdrop click
  if (modal) {
    modal.addEventListener('click', e => {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  // Open external links in a new Chrome tab (more reliable in extensions)
  document.querySelectorAll('#panel-support a[href^="http"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      chrome.tabs.create({ url: a.href });
    });
  });

  // ── Donate button → open GoFundMe ──────────────────────────────────────────
  const donateBtn = $('donateBtn');
  if (donateBtn) {
    donateBtn.onclick = () => {
      chrome.tabs.create({ url: 'https://www.gofundme.com/f/support-free-jobfill-app-for-job-seekers' });
    };
  }

  // ── Share button (future feature) ──────────────────────────────────────────
  const shareAppBtn = $('shareAppBtn');
  if (shareAppBtn) {
    shareAppBtn.onclick = () => {
      // Coming soon — no action yet
    };
  }

  // ── Disclaimer modal (lazy refs — modal HTML is after the script tag) ───────
  const disclaimerBtn = $('disclaimerBtn');
  if (disclaimerBtn) {
    disclaimerBtn.onclick = () => {
      const mo = $('disclaimerModal');
      if (mo) mo.classList.add('show');
    };
  }
  // Close button and backdrop wired lazily on first open
  document.addEventListener('click', e => {
    const mo = $('disclaimerModal');
    if (!mo) return;
    if (e.target.id === 'disclaimerClose' || e.target === mo) {
      mo.classList.remove('show');
    }
  });

  // ── Bugs & Enhancements modal ───────────────────────────────────────────────
  const behModal   = $('bugEnhModal');
  const behOpenBtn = $('bugEnhBtn');
  const behCancel  = $('bugEnhCancel');
  const behSend    = $('bugEnhSend');
  const bugToggle  = $('bugToggle');
  const enhToggle  = $('enhToggle');

  let _behType = 'Bug'; // current selection

  // Open modal
  if (behOpenBtn && behModal) {
    behOpenBtn.onclick = () => {
      // Reset fields each time the modal opens
      ['behWhere','behWhen','behWhy','behHow'].forEach(id => { if($(id)) $(id).value = ''; });
      _behType = 'Bug';
      _updateBehToggle();
      behModal.style.display = 'flex';
    };
  }

  // Toggle styling helper
  function _updateBehToggle() {
    if (!bugToggle || !enhToggle) return;
    if (_behType === 'Bug') {
      bugToggle.style.background  = 'var(--red)';   bugToggle.style.color  = '#fff';
      enhToggle.style.background  = 'var(--bg)';    enhToggle.style.color  = 'var(--text-lt)';
    } else {
      bugToggle.style.background  = 'var(--bg)';    bugToggle.style.color  = 'var(--text-lt)';
      enhToggle.style.background  = 'var(--green)'; enhToggle.style.color  = '#fff';
    }
  }

  if (bugToggle) bugToggle.onclick = () => { _behType = 'Bug';         _updateBehToggle(); };
  if (enhToggle) enhToggle.onclick = () => { _behType = 'Enhancement'; _updateBehToggle(); };

  // Cancel → close modal
  if (behCancel && behModal) {
    behCancel.onclick = () => { behModal.style.display = 'none'; };
  }

  // Close on backdrop click
  if (behModal) {
    behModal.addEventListener('click', e => {
      if (e.target === behModal) behModal.style.display = 'none';
    });
  }

  // Send Report → compose mailto
  if (behSend) {
    behSend.onclick = () => {
      const where = ($('behWhere') || {}).value || '';
      const when  = ($('behWhen')  || {}).value || '';
      const why   = ($('behWhy')   || {}).value || '';
      const how   = ($('behHow')   || {}).value || '';

      // Build a readable date/time with timezone
      const now  = new Date();
      const tzName = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const dtStr = now.toLocaleString('en-US', {
        weekday:'long', year:'numeric', month:'long', day:'numeric',
        hour:'2-digit', minute:'2-digit', second:'2-digit', timeZoneName:'short'
      });

      const subjectTag = _behType === 'Bug' ? 'Bug Report' : 'Enhancement Request';
      const subject = encodeURIComponent(`JobFill ${subjectTag} — v${APP_VERSION}`);

      const body = encodeURIComponent(
        `JobFill ${subjectTag}\n` +
        `Version: ${APP_VERSION}\n` +
        `Reported: ${dtStr} (${tzName})\n` +
        `\n` +
        `WHERE:\n${where || '(not provided)'}\n` +
        `\n` +
        `WHEN:\n${when || '(not provided)'}\n` +
        `\n` +
        `WHY:\n${why || '(not provided)'}\n` +
        `\n` +
        `HOW:\n${how || '(not provided)'}\n`
      );

      window.open(`mailto:selleckg@yahoo.com?subject=${subject}&body=${body}`);
      behModal.style.display = 'none';
    };
  }
})();
